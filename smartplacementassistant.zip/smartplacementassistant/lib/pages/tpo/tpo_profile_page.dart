import 'package:flutter/material.dart';

import '../../my_routes.dart';
import '../../utilsapp/app_colors.dart';
import '../../utilsapp/app_constant.dart';
class TpoProfilePage extends StatefulWidget {
  const TpoProfilePage({Key? key}) : super(key: key);

  @override
  State<TpoProfilePage> createState() => _TpoProfilePageState();
}

class _TpoProfilePageState extends State<TpoProfilePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(title: Text("My Profile"),backgroundColor: AppColor.dashboard_color,),

      body: SafeArea(
        child: Container(
          margin: EdgeInsets.fromLTRB(20, 20, 20, 20),
          child: Column(
            children: [

              Text(AppConstant.name_string,style: TextStyle(color: AppColor.dashboard_color,fontSize: 18,fontWeight: FontWeight.bold),),
              Text(AppConstant.email_string,style: TextStyle(color: AppColor.dashboard_color),),



              //personal details
              InkWell(
                onTap: (){
                  Navigator.pushNamed(context, MyRoutes.tpoPersonalDetailsRoute);
                },
                child: Container(
                    color: AppColor.dashboard_color,
                    margin: EdgeInsets.fromLTRB(20, 20, 20, 0),
                    child: Padding(
                      padding:EdgeInsets.all(10) ,
                      child:Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Icon(Icons.perm_contact_cal_sharp,color: Colors.white,),
                          Text("Personal Details",style: TextStyle(color: Colors.white),),
                          Icon(Icons.arrow_forward_ios_outlined,color: Colors.white,),
                        ],
                      ),
                    )
                ),
              ),



              //Contact details
              InkWell(
                onTap: (){
                  Navigator.pushNamed(context, MyRoutes.tpoContactDetailsRoute);
                },
                child: Container(
                    color: AppColor.dashboard_color,
                    margin: EdgeInsets.fromLTRB(20, 20, 20, 0),
                    child: Padding(
                      padding:EdgeInsets.all(10) ,
                      child:Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Icon(Icons.call,color: Colors.white,),
                          Text("Contact Details",style: TextStyle(color: Colors.white),),
                          Icon(Icons.arrow_forward_ios_outlined,color: Colors.white,),
                        ],
                      ),
                    )
                ),
              ),
            ],
          ),),
      ),
    );
  }
}
