import 'dart:collection';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smartplacementassistant/models/contact__details_model.dart';
import 'package:smartplacementassistant/models/tpo_contact__details_model.dart';

import '../../utilsapp/app_colors.dart';
import '../../utilsapp/app_constant.dart';
class TpoContactDetailsPage extends StatefulWidget {
  const TpoContactDetailsPage({Key? key}) : super(key: key);

  @override
  State<TpoContactDetailsPage> createState() => _TpoContactDetailsPageState();
}

class _TpoContactDetailsPageState extends State<TpoContactDetailsPage> {
  final _formAllKey = GlobalKey<FormState>();
  final _firstNameKey = GlobalKey<FormState>();
  final _lastNameKey = GlobalKey<FormState>();
  final _internKey = GlobalKey<FormState>();

  final emailEditingController = new TextEditingController();
  final contactEditingController = new TextEditingController();
  final secondContactEditingController = new TextEditingController();


  int details_flag=0;

  bool isLoading=false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
   _getDetails();


  }

  @override
  Widget build(BuildContext context) {
    final submit_button=  Container(
      margin: EdgeInsets.fromLTRB(10, 10, 10, 10),
      width: MediaQuery.of(context).size.width * 0.91,
      height: 55,
      child: ElevatedButton(

        onPressed: ()  {
          details_flag ==0 ?  submitDetails(emailEditingController.text, contactEditingController.text,secondContactEditingController.text):
              updateDetails(emailEditingController.text, contactEditingController.text,secondContactEditingController.text);

        },
        style: ElevatedButton.styleFrom(
          primary: AppColor.button_color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10  ),
          ),
          elevation: 10.0,
        ),
        child:  Text(
         details_flag == 0 ? "Submit" : "Update",
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );

    final emailField = Form(  key: _formAllKey,child:TextFormField(
        autofocus: false,
        controller: emailEditingController,

        keyboardType: TextInputType.emailAddress,
        validator: (value) {
          RegExp regex = new RegExp(r'^.{3,}$');
          if (value!.isEmpty) {
            return (" email cannot be Empty");
          }
          /*  if (!regex.hasMatch(value)) {
            return ("Enter Valid name(Min. 3 Character)");
          }*/
          return null;
        },
        onSaved: (value) {
          emailEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "Your Email",
       
          enabledBorder:   OutlineInputBorder(
            // width: 0.0 produces a thin "hairline" border
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        )) );
    final contactField =Form(  key: _firstNameKey,child: TextFormField(
        autofocus: false,

        controller: contactEditingController,
        keyboardType: TextInputType.number,
        validator: (value) {
          RegExp regex = new RegExp(r'^.{3,}$');
          if (value!.isEmpty) {
            return ("contact cannot be Empty");
          }

          return null;
        },
        onSaved: (value) {
          contactEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "Primary Contact Number",
        
          enabledBorder:   OutlineInputBorder(
            // width: 0.0 produces a thin "hairline" border
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ))) ;
    
    final parentContactField =Form(   key: _lastNameKey,child: TextFormField(
        autofocus: false,

        controller:secondContactEditingController ,
        keyboardType: TextInputType.number,
        validator: (value) {
          RegExp regex = new RegExp(r'^.{3,}$');
          if (value!.isEmpty) {
            return ("contact cannot be Empty");
          }

          return null;
        },
        onSaved: (value) {
          secondContactEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "Second Contact Number",
           enabledBorder:   OutlineInputBorder(
            // width: 0.0 produces a thin "hairline" border
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ))) ;




    return Scaffold(

      appBar:AppBar(title: Text("Contact Details"),backgroundColor: AppColor.dashboard_color,),
      
      body: SafeArea(
        child: SingleChildScrollView(
          child: isLoading ==false ? Center(child: CircularProgressIndicator()) : Container(
            margin: EdgeInsets.fromLTRB(20, 20, 20, 20),
            child: Column(
           
           children: [
             
             emailField,
             SizedBox(height: 20,),
             contactField,
             SizedBox(height: 20,),
             parentContactField,
             SizedBox(height: 20,),

             submit_button
             
           ], 
          )
            ,),),
      ),
    );
  }

  Future<void> submitDetails(String email, String contact_number, String second_contact_number) async {

    DatabaseReference _dbref = FirebaseDatabase.instance.reference();

    TpoContactDetailsModel contactDetailsModel= new TpoContactDetailsModel();
    contactDetailsModel.email=email;
    contactDetailsModel.contact_number=contact_number;
    contactDetailsModel.second_contact_number=second_contact_number;


    await _dbref.child(AppConstant.MAIN_TABLE).child(
        AppConstant.TPO_TABLE).child(
        AppConstant.uid_string).child(
        AppConstant.CONTACT_DETAILS_TABLE).get().then((value) => {

      if(value.exists)
        {
          Fluttertoast.showToast(msg: "Details Already saved! ")
        }
      else{
        _dbref.child(AppConstant.MAIN_TABLE).child(
            AppConstant.TPO_TABLE).child(
           AppConstant.uid_string).child(
            AppConstant.CONTACT_DETAILS_TABLE)
            .set(contactDetailsModel.toMap())
            .whenComplete(() {
          Fluttertoast.showToast(msg: "Details submit successfully! ");
          Navigator.pop(context);
        }

        )



      }
    });
  }

  _getDetails() async {

    DatabaseReference _dbref = FirebaseDatabase.instance.reference();

    await _dbref.child(AppConstant.MAIN_TABLE).child(
        AppConstant.TPO_TABLE).child(
        AppConstant.uid_string).child("contact_details").once().then((snapshot)   {
      isLoading=true;
      if(snapshot.exists)
        {
          setState((){
             details_flag=1;
              });

          print(snapshot.value.toString());
          print(snapshot.value["contact_number"].toString());

          emailEditingController.text=snapshot.value["email"].toString();
          contactEditingController.text=snapshot.value["contact_number"].toString();
          secondContactEditingController.text=snapshot.value["second_contact_number"].toString();

      }
      else{
        setState((){
          details_flag=0;
        });
        Fluttertoast.showToast(msg: "Enter All the details! ");
      }
    });

  }

  updateDetails(String email, String contact_number, String second_contact_number) async {
    DatabaseReference _dbref = FirebaseDatabase.instance.reference();

    TpoContactDetailsModel contactDetailsModel= new TpoContactDetailsModel();
    contactDetailsModel.email=email;
    contactDetailsModel.contact_number=contact_number;
    contactDetailsModel.second_contact_number=second_contact_number;


    await _dbref.child(AppConstant.MAIN_TABLE).child(
        AppConstant.TPO_TABLE).child(
      AppConstant.uid_string).child(
        AppConstant.CONTACT_DETAILS_TABLE).get().then((value) => {


        _dbref.child(AppConstant.MAIN_TABLE).child(
            AppConstant.TPO_TABLE).child(
           AppConstant.uid_string).child(
            AppConstant.CONTACT_DETAILS_TABLE)
            .update(contactDetailsModel.toMap())
            .whenComplete(() {
          Fluttertoast.showToast(msg: "Details updated successfully! ");
          Navigator.pop(context);
        }

        )




    });

  }
}
