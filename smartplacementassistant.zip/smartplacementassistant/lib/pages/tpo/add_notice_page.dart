import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smartplacementassistant/models/notice_model.dart';
import 'package:smartplacementassistant/pages/tpo/tpo_dashboard.dart';

import '../../utilsapp/app_colors.dart';
import '../../utilsapp/app_constant.dart';
class AddNoticePage extends StatefulWidget {
  final String notice_text,notice_id;
  const AddNoticePage({Key? key, required this.notice_text, required this.notice_id}) : super(key: key);

  @override
  State<AddNoticePage> createState() => _AddNoticePageState(notice_text:notice_text,notice_id: notice_id);
}

class _AddNoticePageState extends State<AddNoticePage> {
  final _formAllKey = GlobalKey<FormState>();

  final noticeEditingController = new TextEditingController();
  late String notice_text,notice_id;

  _AddNoticePageState({
    required this.notice_text,
    required this.notice_id,
  });

bool isEdit=false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setState((){

      if(notice_id.isNotEmpty)
      {
        noticeEditingController.text=notice_text;
        isEdit=true;
        print("got it $notice_id");
      }else
        {
          print("empty");
        }
    });

  }

  @override
  Widget build(BuildContext context) {



    final submit_button=  Container(
      margin: EdgeInsets.fromLTRB(10, 10, 10, 10),
      width: MediaQuery.of(context).size.width * 0.91,
      height: 55,
      child: ElevatedButton(

        onPressed: ()  {
         notice_id.isEmpty ?  submitDetails(noticeEditingController.text):
      updateDetails(noticeEditingController.text, notice_id);

        },
        style: ElevatedButton.styleFrom(
          primary: AppColor.button_color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10  ),
          ),
          elevation: 10.0,
        ),
        child:  Text(
           "Submit",
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );

    final noticeField = Form(  key: _formAllKey,child:TextFormField(
        autofocus: false,
        controller: noticeEditingController,

        keyboardType: TextInputType.multiline,
        maxLines: null,
        validator: (value) {

          if (value!.isEmpty) {
            return ("notice cannot be Empty");
          }

          return null;
        },
        onSaved: (value) {
          noticeEditingController.text = value!;
        },
        textInputAction: TextInputAction.newline,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: const EdgeInsets.symmetric(vertical: 45.0, horizontal: 10.0),
          labelText: "Add Notice",
          enabledBorder:   OutlineInputBorder(
            // w
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        )) );
    return Scaffold(

      appBar:AppBar(title: Text("Add Notice"),backgroundColor: AppColor.dashboard_color,),

      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            margin: EdgeInsets.all(20),
            child: Column(

              children: [
                 noticeField,
                SizedBox(height: 20,),
                submit_button,
              ],
            ),
          ),
        ),
      ),

    );
  }

  Future<void> submitDetails(String text) async {

    if (_formAllKey.currentState!.validate()) {
      DatabaseReference _dbref = FirebaseDatabase.instance.reference();
        NoticeModel noticeModel = NoticeModel();
       var _id=  _dbref.push().key.toString();
       noticeModel.notice = text;
      noticeModel.id= _id;

      await _dbref.child("notice").child(_id)
              .set(noticeModel.toMap())
              .whenComplete(() {
             Fluttertoast.showToast(msg: "Notice Submitted");
            Navigator.pop(context);
          }
     );
   }
    else{
      Fluttertoast.showToast(msg: "Something went wrong! ");
    }
  }

  updateDetails(String text,String _id) async {

    if (_formAllKey.currentState!.validate()) {
      DatabaseReference _dbref = FirebaseDatabase.instance.reference();


      await _dbref.child("notice").child(notice_id)
              .update({"notice" : text});

             Fluttertoast.showToast(msg: "Notice Updated| Do refresh.");
            Navigator.pop(context);


   }
    else{
      Fluttertoast.showToast(msg: "Something went wrong! ");
    }
  }


}
