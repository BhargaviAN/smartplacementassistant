import 'dart:collection';

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
 import 'package:fluttertoast/fluttertoast.dart';
  import 'package:smartplacementassistant/pages/tpo/send_notification_page.dart';

import '../../models/notification_model.dart';
import '../../models/user_model.dart';
import '../../utilsapp/app_colors.dart';
import '../../utilsapp/app_constant.dart';
class StudentListPage extends StatefulWidget {
  const StudentListPage({Key? key}) : super(key: key);

  @override
  State<StudentListPage> createState() => _StudentListPageState();
}

class _StudentListPageState extends State<StudentListPage> {


  List<UserModel> userModelList=[];

  String dropdownvalue = 'Artificial Intelligence and Machine Learning';

  String cgpadropdown="9.5";
  var cgpaitems =["9.5","9.0","8.5","8.0","7.5","7.0","6.5","6.0"];

  var items = [
    'Artificial Intelligence and Machine Learning',
    'Biotechnology Engineering',
    'Computer Science and Engineering',
    'Electronics and Communication Engineering'
    'Civil Engineering',
    'Information Science and Engineering',
    'Electrical and Electronics Engineering',
    'Industrial Production Engineering',
    'Mechanical Engineering',
    'Electrical and Instrumentation Engineering',
    'Automobile Engineering',
  ];

  late DatabaseReference _dbref;
  bool isLoading=false;
  bool isSelected=false;
  bool isMultiSelectionEnabled = false;

  HashSet<UserModel> selectedItem = HashSet();
   @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _dbref = FirebaseDatabase.instance.reference();

    getStudentData();




  }



  Future<void> getStudentData()
  async {
    await _dbref.child(AppConstant.MAIN_TABLE).child(AppConstant.STUDENT_TABLE).once()
        .then((snapshot) {
      print("valueupdate " + snapshot.value.toString());
      if(userModelList.isNotEmpty)userModelList.clear();
      if (snapshot.exists) {
        Map<dynamic, dynamic> values = snapshot.value;
        values.forEach((key,values) {

          print(values["name"]);

          print(values["email"].toString());

          setState((){
            isLoading=true;


            UserModel userModel= new UserModel();
            userModel.name=values["name"];
            userModel.email=values["email"];
            userModel.uid=values["uid"];
            userModel.department=values["department"];
            userModel.cgpa=values["cgpa"];
            userModelList.add(userModel);

          });


        });

      } else {
        isLoading=true;
        Fluttertoast.showToast(msg: 'Data not found!');
      }

    });
  }

  Future<void> getDepartmentStudentData()
  async {
    await _dbref.child(AppConstant.MAIN_TABLE).child(AppConstant.STUDENT_TABLE).orderByChild("department").equalTo(dropdownvalue).once()
        .then((snapshot) {
      print("dropvalueupdate " + snapshot.value.toString());

      if(userModelList.isNotEmpty)userModelList.clear();
      if (snapshot.exists) {
        Map<dynamic, dynamic> values = snapshot.value;
        values.forEach((key,values) {

          print(values["name"]);

          print(values["email"].toString());

          setState((){
            isLoading=true;


            UserModel userModel= new UserModel();
            userModel.name=values["name"];
            userModel.email=values["email"];
            userModel.uid=values["uid"];
            userModel.department=values["department"];
            userModel.cgpa=values["cgpa"];
            userModelList.add(userModel);

          });


        });

      } else {
        isLoading=true;
        Fluttertoast.showToast(msg: 'Data not found!');
      }

    });
  }

  Future<void> getCGPAStudentData()
  async {
    await _dbref.child(AppConstant.MAIN_TABLE).child(AppConstant.STUDENT_TABLE).orderByChild("cgpa").startAt(cgpadropdown).once()
        .then((snapshot) {
      print("dropvalueupdate " + snapshot.value.toString());

      if(userModelList.isNotEmpty)userModelList.clear();
      if (snapshot.exists) {
        Map<dynamic, dynamic> values = snapshot.value;
        values.forEach((key,values) {



          setState((){
            isLoading=true;


            UserModel userModel= new UserModel();
            userModel.name=values["name"];
            userModel.email=values["email"];
            userModel.uid=values["uid"];
            userModel.department=values["department"];
            userModel.cgpa=values["cgpa"];
            userModelList.add(userModel);

          });


        });

      } else {
        isLoading=true;
        Fluttertoast.showToast(msg: 'Data not found!');
      }

    });
  }

     buildListItem(BuildContext context,int index, bool selected) {
    return Card(
      margin: EdgeInsets.all(10),
      elevation: selected ? 2 : 10,
      child: ListTile(
        leading: FlutterLogo(),
        contentPadding: EdgeInsets.all(10),
        title: Text(userModelList[index].name.toString()),
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    final dep_button=  Container(
      margin: EdgeInsets.fromLTRB(10, 10, 10, 10),
      width: 90,
      height:40,

      child: ElevatedButton(

        onPressed: ()  {
          getDepartmentStudentData();
        },
        style: ElevatedButton.styleFrom(
          primary: AppColor.button_color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10  ),
          ),

        ),
        child:  Text(
          "Filter" ,
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 15, color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );
    final cgpa_button=  Container(
      margin: EdgeInsets.fromLTRB(10, 10, 10, 10),
      width: 90,
      height:40,

      child: ElevatedButton(

        onPressed: ()  {
          getCGPAStudentData();
        },
        style: ElevatedButton.styleFrom(
          primary: AppColor.button_color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10  ),
          ),

        ),
        child:  Text(
          "Filter" ,
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 15, color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );
    return Scaffold(

      appBar:AppBar(
        title: Text("Student List"),backgroundColor: AppColor.dashboard_color,
      actions: [
        InkWell(
          onTap: (){

          selectedItem.isNotEmpty ?  Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => SendNotificationPage(selectedItem: selectedItem,))):
          Fluttertoast.showToast(msg: 'Select Any Student');

          },
          child: Padding(
              padding: EdgeInsets.fromLTRB(0, 0, 10, 0),
              child: Icon(Icons.gpp_good,color: Colors.white,)),
        ),

        InkWell(
          onTap: (){

            getStudentData();

          },
          child: Padding(
              padding: EdgeInsets.fromLTRB(0, 0, 10, 0),
              child: Icon(Icons.filter_alt_off_rounded,color: Colors.white,)),
        ),
      ],
      ),

      body:SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 20,),
            Text(
              " Department Filter:",
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 15, color: Colors.black, fontWeight: FontWeight.bold),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                Container(
                  margin: EdgeInsets.all(5),
                  width: 200,

                  child: Padding(
                    padding: EdgeInsets.all(5),
                    child: DropdownButton(

                      style: TextStyle(fontSize: 13,color: Colors.black),
                      // Initial Value
                      value: dropdownvalue,
                      menuMaxHeight: 250,


                      isExpanded: true,
                      // Down Arrow Icon
                      icon:  Icon(Icons.keyboard_arrow_down),

                      // Array list of items
                      items: items.map((String items) {
                        return DropdownMenuItem(
                          value: items,
                          child: Text(items),
                        );
                      }).toList(),
                      hint: Text("Choose any"),
                      onChanged: (String? newValue) {
                        setState(() {
                          dropdownvalue = newValue!;
                        });
                      },
                    ),
                  ),
                ),dep_button],
            ),

            SizedBox(height: 20,),
            //CGPA FILTEr
            Text(
              " CGPA Filter:",
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 15, color: Colors.black, fontWeight: FontWeight.bold),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                Container(
                  margin: EdgeInsets.all(5),
                  width: 200,

                  child: Padding(
                    padding: EdgeInsets.all(5),
                    child: DropdownButton(

                      style: TextStyle(fontSize: 13,color: Colors.black),
                      // Initial Value
                      value: cgpadropdown,
                      menuMaxHeight: 250,

                      isExpanded: true,
                      // Down Arrow Icon
                      icon:  Icon(Icons.keyboard_arrow_down),

                      // Array list of items
                      items: cgpaitems.map((String items) {
                        return DropdownMenuItem(
                          value: items,
                          child: Text(items),
                        );
                      }).toList(),
                      // After selecting the desired option,it will
                      // change button value to selected value
                      onChanged: (String? newValue) {
                        setState(() {
                          cgpadropdown = newValue!;
                        });
                      },
                    ),
                  ),
                ),cgpa_button],
            ),


            SizedBox(height: 20,),





            Container(
              height: 300,
              child: ListView(
                children: userModelList.map((userone){
                  return Container(
                    child: getListItem(userone),
                    margin: EdgeInsets.fromLTRB(15, 10, 15, 0),
                    padding: EdgeInsets.all(5),
                    color: Colors.green[100],
                  );
                }).toList(),
              ),
            ),
          ],

        ),
      ),

    );
  }

  /*
  *
  *  ListTile(
                        title: Text(userone.name.toString()),
                        subtitle: Text(userone.department.toString() + " \nCGPA : "+userone.cgpa.toString()),
                        leading: Icon(Icons.select_all),
                        trailing:   Icon(Icons.download_done_outlined),

                      ),
  * */

  String getSelectedItemCount() {
    return selectedItem.isNotEmpty
        ? selectedItem.length.toString() + " item selected"
        : "No item selected";
  }

  void doMultiSelection(UserModel userModel) {
    if (isMultiSelectionEnabled) {
      if (selectedItem.contains(userModel)) {
        selectedItem.remove(userModel);
      } else {
        selectedItem.add(userModel);
      }
      setState(() {});
    } else {
      //Other logic
    }
  }


  InkWell getListItem(UserModel userModel) {
    return InkWell(
        onTap: () {
          doMultiSelection(userModel);
        },
        onLongPress: () {
          isMultiSelectionEnabled = true;
          doMultiSelection(userModel);
        },
        child: Stack(alignment: Alignment.centerRight, children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              const SizedBox(
                width: 10,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const SizedBox(
                      height: 10,
                    ),
                    Text(userModel.name.toString(),style: TextStyle(color: Colors.black,fontSize: 18),),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(userModel.department.toString()),
                    const SizedBox(
                      height: 10,
                    ),
                    Text("CGPA : "+userModel.cgpa.toString()),
                    const SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              )
            ],
          ),
          Visibility(
              visible: isMultiSelectionEnabled,
              child: Icon(
                selectedItem.contains(userModel)
                    ? Icons.check_circle
                    : Icons.radio_button_unchecked,
                size: 30,
                color: Colors.red,
              ))
        ]));
  }



}
