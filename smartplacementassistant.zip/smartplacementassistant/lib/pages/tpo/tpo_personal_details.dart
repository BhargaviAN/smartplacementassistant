 import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:smartplacementassistant/models/personal_details_model.dart';
import 'package:smartplacementassistant/models/tpo_personal_details_model.dart';
import 'package:smartplacementassistant/pages/student/fill_application.dart';

import '../../utilsapp/app_colors.dart';
import '../../utilsapp/app_constant.dart';
class TpoPersonalDetailsPage extends StatefulWidget {
  const TpoPersonalDetailsPage({Key? key}) : super(key: key);

  @override
  State<TpoPersonalDetailsPage> createState() => _TpoPersonalDetailsPageState();
}

class _TpoPersonalDetailsPageState extends State<TpoPersonalDetailsPage> {
  final _formAllKey = GlobalKey<FormState>();
  final _firstNameKey = GlobalKey<FormState>();
  final _lastNameKey = GlobalKey<FormState>();

  final departmentEditingController = new TextEditingController();
  final firstNameEditingController = new TextEditingController();
  final lastNameEditingController = new TextEditingController();

  static String gender="male";


  int details_flag=0;

  bool isLoading=false;

  @override
  void initState() {

    super.initState();

    _getDetails();
  }

  @override
  Widget build(BuildContext context) {

    final submit_button=  Container(
      margin: EdgeInsets.fromLTRB(10, 10, 10, 10),
      width: MediaQuery.of(context).size.width * 0.91,
      height: 55,
      child: ElevatedButton(

        onPressed: ()  {
        details_flag ==0 ?  submitDetails( firstNameEditingController.text,lastNameEditingController.text,departmentEditingController.text,gender)
          : updateDetails( firstNameEditingController.text,lastNameEditingController.text,departmentEditingController.text,gender);

        },
        style: ElevatedButton.styleFrom(
          primary: AppColor.button_color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10  ),
          ),
          elevation: 10.0,
        ),
        child:  Text(
          details_flag ==0 ?   "Submit" : "Update",
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );

    final enrollmentNoField = Form(  key: _formAllKey,child:TextFormField(
        autofocus: false,
        controller: departmentEditingController,

        keyboardType: TextInputType.name,
        validator: (value) {
          RegExp regex = new RegExp(r'^.{3,}$');
          if (value!.isEmpty) {
            return ("Department cannot be Empty");
          }
          /*  if (!regex.hasMatch(value)) {
            return ("Enter Valid name(Min. 3 Character)");
          }*/
          return null;
        },
        onSaved: (value) {
          departmentEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "Department",
          enabledBorder:   OutlineInputBorder(
            // width: 0.0 produces a thin "hairline" border
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        )) );
    final firstNameField =Form(  key: _firstNameKey,child: TextFormField(
        autofocus: false,

        controller: firstNameEditingController,
        keyboardType: TextInputType.name,
        validator: (value) {
          RegExp regex = new RegExp(r'^.{3,}$');
          if (value!.isEmpty) {
            return ("First Name cannot be Empty");
          }
          if (!regex.hasMatch(value)) {
            return ("Enter Valid name(Min. 3 Character)");
          }
          return null;
        },
        onSaved: (value) {
          firstNameEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "First Name",
          enabledBorder:   OutlineInputBorder(

            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ))) ;
    final lastNameField =Form(   key: _lastNameKey,child: TextFormField(
        autofocus: false,

        controller:lastNameEditingController ,
        keyboardType: TextInputType.name,
        validator: (value) {
          RegExp regex = new RegExp(r'^.{3,}$');
          if (value!.isEmpty) {
            return ("last Name cannot be Empty");
          }
          if (!regex.hasMatch(value)) {
            return ("Enter Valid name(Min. 3 Character)");
          }
          return null;
        },
        onSaved: (value) {
          lastNameEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "Last Name",
          enabledBorder:   OutlineInputBorder(
            // width: 0.0 produces a thin "hairline" border
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ))) ;

    return Scaffold(
      appBar:AppBar(title: Text("Personal Details"),backgroundColor: AppColor.dashboard_color,),
      body: SafeArea(
        child: SingleChildScrollView(
          child: isLoading ==false ? Center(child: CircularProgressIndicator()) :  Container(
            margin: EdgeInsets.fromLTRB(20, 20, 20, 20),
            child: Column(

              children: [

                firstNameField,
                SizedBox(height: 20,),
                lastNameField,
                SizedBox(height: 20,),
                enrollmentNoField,






    Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
    const Text('Please select gender:'),
    ListTile(
    leading: Radio<String>(
    value: 'male',
    groupValue: gender,
    onChanged: (value) {
    setState(() {
    gender = value!;
    });
    },
    ),
    title: const Text('Male'),
    ),
    ListTile(
    leading: Radio<String>(
    value: 'female',
    groupValue: gender,
    onChanged: (value) {
    setState(() {
    gender = value!;
    });
    },
    ),
    title: const Text('Female'),
    ),
    ]
    ),

                submit_button,



              ],
            ),
          ),
        ),
      ),
    );
  }

   void submitDetails(  String firstName, String lastName, String department, String gender) async {

    if ( _firstNameKey.currentState!.validate()&& _lastNameKey.currentState!.validate() && _formAllKey.currentState!.validate()) {
      DatabaseReference _dbref = FirebaseDatabase.instance.reference();


      TpoPersonalDetailsModel personalDetailsModel = TpoPersonalDetailsModel();
      personalDetailsModel.first_name = firstName;
      personalDetailsModel.last_name = lastName;
      personalDetailsModel.department = department;
      personalDetailsModel.gender = gender;


      await _dbref.child(AppConstant.MAIN_TABLE).child(
          AppConstant.TPO_TABLE).child(
         AppConstant.uid_string).child(
          AppConstant.PERSONAL_DETAILS_TABLE).once().then((value) => {

            if(value.exists)
              {
                   Fluttertoast.showToast(msg: "Details Already saved! ")
              }
            else{
          _dbref.child(AppConstant.MAIN_TABLE).child(
          AppConstant.TPO_TABLE).child(
              AppConstant.uid_string).child(
          AppConstant.PERSONAL_DETAILS_TABLE)
          .set(personalDetailsModel.toMap())
          .whenComplete(() {
        Fluttertoast.showToast(msg: "Details submit successfully! ");
        Navigator.pop(context);
      }

      )



            }
      });

    }
    else{
      Fluttertoast.showToast(msg: "Enter All data! ");
    }
  }




  _getDetails() async {

    DatabaseReference _dbref = FirebaseDatabase.instance.reference();

    await _dbref.child(AppConstant.MAIN_TABLE).child(
        AppConstant.TPO_TABLE).child(
        AppConstant.uid_string).child("personal_details").once().then((snapshot)   {

          isLoading=true;
      if(snapshot.exists)
      {
        setState((){
          details_flag=1;
        });

        print(snapshot.value.toString());

        departmentEditingController.text=snapshot.value["department"].toString();
        firstNameEditingController.text=snapshot.value["first_name"].toString();
        lastNameEditingController.text=snapshot.value["last_name"].toString();
         if(snapshot.value["gender"].toString()=="male")
          {
           setState((){
             gender ="male";
           });
          }else{
          setState((){
            gender ="female";
          });
        }

      }
      else{
        setState((){
          details_flag=0;
        });
        Fluttertoast.showToast(msg: "Enter All the details! ");
      }
    });

  }

  void updateDetails(String firstName, String lastName, String department, String gender) async {

    if (_formAllKey.currentState!.validate()&& _firstNameKey.currentState!.validate()&& _lastNameKey.currentState!.validate()) {
      DatabaseReference _dbref = FirebaseDatabase.instance.reference();


      PersonalDetailsModel personalDetailsModel = PersonalDetailsModel();

      // writing all the values

      personalDetailsModel.first_name = firstName;
      personalDetailsModel.last_name = lastName;

      personalDetailsModel.universityseat_no = department;
      personalDetailsModel.gender = gender;


      await _dbref.child(AppConstant.MAIN_TABLE).child(
              AppConstant.TPO_TABLE).child(
          AppConstant.uid_string).child(
              AppConstant.PERSONAL_DETAILS_TABLE)
              .update(personalDetailsModel.toMap())
              .whenComplete(() {
            Fluttertoast.showToast(msg: "Details updated successfully! ");
            Navigator.pop(context);
          }

          );





    }
    else{
      Fluttertoast.showToast(msg: "Enter All data! ");
    }
  }
  
}
