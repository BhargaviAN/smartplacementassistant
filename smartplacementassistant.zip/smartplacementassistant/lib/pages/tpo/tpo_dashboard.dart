import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smartplacementassistant/pages/login_tpo_page.dart';
import 'package:smartplacementassistant/pages/tpo/add_notice_page.dart';

import '../../models/notice_model.dart';
import '../../my_routes.dart';
import '../../utilsapp/app_colors.dart';
import '../../utilsapp/app_constant.dart';
class TpoDashboard extends StatefulWidget {
  const TpoDashboard({Key? key}) : super(key: key);

  @override
  State<TpoDashboard> createState() => _TpoDashboardState();
}

class _TpoDashboardState extends State<TpoDashboard> {

  String name="",email="";

  late DatabaseReference _dbref;
  bool isLoading=false;
  bool isNoticeLoading=false;

  static String notice="";

  List<NoticeModel> noticeModelList=[];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _dbref = FirebaseDatabase.instance.reference();

    getTpoData();
    getNoticeData();
  }
  Future<void> getNoticeData()
  async {
    await _dbref.child("notice").once()
        .then((snapshot) {
      print("saasd " + snapshot.value.toString());

      if(noticeModelList.isNotEmpty) noticeModelList.clear();
      if (snapshot.exists) {
        Map<dynamic, dynamic> values = snapshot.value;
        values.forEach((key,values) {


          setState((){
            isNoticeLoading=true;

            NoticeModel userModel= new NoticeModel();
            userModel.id=values["id"];
            userModel.notice=values["notice"];

            noticeModelList.add(userModel);


            noticeModelList= noticeModelList.reversed.toList();
          });


        });

      } else {
        isNoticeLoading=true;
        Fluttertoast.showToast(msg: 'Data not found!');
      }

    });
  }

  Future<void> getTpoData()
  async {
    await _dbref.child(AppConstant.MAIN_TABLE).child(AppConstant.TPO_TABLE)
        .orderByChild("uid").equalTo(AppConstant.uid_string).once()
        .then((snapshot) {
      print("valueupdate " + snapshot.value.toString());

      if (snapshot.exists) {
        Map<dynamic, dynamic> values = snapshot.value;
        values.forEach((key,values) {

          print(values["name"]);

          print(values["email"].toString());

          setState((){
            isLoading=true;
            name=values["name"];
            email=values["email"];

            AppConstant.name_string=values["name"];
            AppConstant.email_string=values["email"];
          });


        });

      } else {
        isLoading=true;
        Fluttertoast.showToast(msg: 'Data not found!');
      }

    });
  }


  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text("Dashboard",style: TextStyle(
            color: Colors.white
        ),),
        backgroundColor: AppColor.dashboard_color,
        actions: [
          InkWell(
            onTap: (){

          getNoticeData();

            },
            child: Padding(
                padding: EdgeInsets.fromLTRB(0, 0, 10, 0),
                child: Icon(Icons.refresh,color: Colors.white,)),
          ),
          InkWell(
            onTap: (){

              Navigator.pushAndRemoveUntil<dynamic>(
                context,
                MaterialPageRoute<dynamic>(
                  builder: (BuildContext context) => LoginTpoPage(),
                ),
                    (route) => false,//if you want to disable back feature set to false
              );
              Fluttertoast.showToast(msg: 'Logout successfully');
            },
            child: Padding(
                padding: EdgeInsets.fromLTRB(0, 0, 10, 0),
                child: Icon(Icons.logout,color: Colors.white,)),
          ),
        ],
      ),


      body:SafeArea(

        child: SingleChildScrollView(
          child: Column(

            children: [
              SizedBox(height: 50,),
              Center(child:     Text("Welcome To TPO Dashboard!",style: TextStyle(
                  fontSize: 20,fontWeight: FontWeight.bold
              ),) ,),
              SizedBox(height: 20),
              Center(child:     Text("All Notice List",style: TextStyle(
                  fontSize: 16,fontWeight: FontWeight.w700
              ),) ,),


              isNoticeLoading ==false?  Column(
                children: [
                  SizedBox(height: 100,),

                  Center(child:     Text("No notice yet!") ,),

                  CircularProgressIndicator(),],
              ):  Column(
                children: noticeModelList.map((userone){
                  return Container(
                    child: InkWell(
                      onLongPress: (){
                        FirebaseDatabase.instance.reference().child("notice").child(userone.id.toString()).remove().then((value) {
                          Fluttertoast.showToast(msg: "Notice Deleted!");

                          getNoticeData();
                        }

                        );
                      },
                      onTap: (){
                        notice=userone.notice.toString();
                       // Navigator.pushNamed(context, MyRoutes.noticeRoute);

                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => AddNoticePage(notice_text: userone.notice.toString(), notice_id: userone.id.toString())),);
                      },
                      child: ListTile(

                        title: Text(userone.notice.toString()),
                      ),
                    ),
                    margin: EdgeInsets.fromLTRB(15, 10, 15, 0),
                    padding: EdgeInsets.all(5),
                    color: Colors.green[100],
                  );
                }).toList(),
              ),
            ],
          ),
        ),
      ) ,

      drawer: Drawer(
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: <Widget>[
            UserAccountsDrawerHeader(
              decoration: BoxDecoration(
                color: AppColor.dashboard_color,
              ),
              accountName: Text(isLoading ? name : " loading...",style: TextStyle(color: Colors.white),),
              accountEmail: Text(isLoading ? email: "",style: TextStyle(color: Colors.white),),
              currentAccountPicture: CircleAvatar(
                backgroundColor: Colors.red,
                child: Text(
                  isLoading ? name.substring(0,1) : " ",
                  style: TextStyle(fontSize: 40.0),
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home), title: Text("Dashboard"),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(Icons.account_circle_outlined), title: Text("Profile"),
              onTap: () {

                Navigator.pop(context);
                Navigator.pushNamed(context, MyRoutes.tpoProfileRoute);
              },
            ),
            ListTile(
              leading: Icon(Icons.list_alt), title: Text("Student List"),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, MyRoutes.studentListRoute);

              },
            ), ListTile(
              leading: Icon(Icons.add), title: Text("Add Notice"),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AddNoticePage(notice_text: "", notice_id: "")),);

              },
            ),
          ],
        ),

      ),
    );
  }
}
