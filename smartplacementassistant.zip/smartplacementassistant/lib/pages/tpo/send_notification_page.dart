import 'dart:collection';

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smartplacementassistant/models/user_model.dart';

import '../../models/notification_model.dart';
import '../../utilsapp/app_colors.dart';
import '../../utilsapp/app_constant.dart';
class SendNotificationPage extends StatefulWidget {
final HashSet<UserModel> selectedItem;
  const SendNotificationPage({Key? key, required this.selectedItem,}) : super(key: key);

  @override
  State<SendNotificationPage> createState() => _SendNotificationPageState(selectedItem);
}

class _SendNotificationPageState extends State<SendNotificationPage> {

  final _formAllKey = GlobalKey<FormState>();

  final notificationEditingController = new TextEditingController();
  HashSet<UserModel> selectedItem;


  _SendNotificationPageState(this.selectedItem);


List<String> userListNames=[];


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setState((){
      for(var userModel in selectedItem) {
        print(userModel.name);
        userListNames.add(userModel.name.toString());
      }
    });
  }
  @override
  Widget build(BuildContext context) {


    final submit_button=  Container(
      margin: EdgeInsets.fromLTRB(10, 10, 10, 10),
      width: MediaQuery.of(context).size.width * 0.91,
      height: 55,
      child: ElevatedButton(

        onPressed: ()  {
    for(var userModel in selectedItem) {
      selectStuNotification(notificationEditingController.text,userModel.uid.toString());
    }




        },
        style: ElevatedButton.styleFrom(
          primary: AppColor.button_color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10  ),
          ),
          elevation: 10.0,
        ),
        child:  Text(
          "Send Notification",
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );

    final noticeField = Form(  key: _formAllKey,child:TextFormField(
        autofocus: false,
        controller: notificationEditingController,

        keyboardType: TextInputType.multiline,
        maxLines: null,
        validator: (value) {

          if (value!.isEmpty) {
            return ("message cannot be Empty");
          }

          return null;
        },
        onSaved: (value) {
          notificationEditingController.text = value!;
        },
        textInputAction: TextInputAction.newline,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: const EdgeInsets.symmetric(vertical: 45.0, horizontal: 10.0),
          labelText: "Write Message",
          enabledBorder:   OutlineInputBorder(
            // w
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        )) );

    return Scaffold(

      appBar:AppBar(title: Text("Send notification to Students",style: TextStyle(color: Colors.black,fontSize: 18),),backgroundColor: AppColor.dashboard_color,),

      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            margin: EdgeInsets.all(20),
            child: Column(

              children: [
                Text("You selected .${userListNames.toString()}",style: TextStyle(color: Colors.black),),
                SizedBox(height: 20,),
                Text("Write your message below.",style: TextStyle(color: Colors.black),),
                noticeField,
                SizedBox(height: 20,),
                submit_button,
              ],
            ),
          ),
        ),
      ),

    );;
  }


  Future<void> selectStuNotification(String text,String stu_id) async {


    DatabaseReference _dbref = FirebaseDatabase.instance.reference();


    NotificationModel noticeModel = NotificationModel();


    var _id=  _dbref.push().key.toString();

    noticeModel.notification_text = text;
    noticeModel.id= _id;


    await _dbref.child(AppConstant.MAIN_TABLE).child(
        AppConstant.STUDENT_TABLE).child(
        stu_id).child(
        "notifications").child(_id)
        .set(noticeModel.toMap())
        .whenComplete(() {


      Fluttertoast.showToast(msg: 'Notification sent to Student');
      Navigator.pop(context);

    }

    );






  }


}
