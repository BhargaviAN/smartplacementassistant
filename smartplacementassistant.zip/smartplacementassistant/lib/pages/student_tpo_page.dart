import 'package:flutter/material.dart';
import 'package:smartplacementassistant/pages/login_tpo_page.dart';

import '../utilsapp/app_colors.dart';
import 'login_page.dart';
class StudentTpoPage extends StatefulWidget {
  const StudentTpoPage({Key? key}) : super(key: key);

  @override
  State<StudentTpoPage> createState() => _StudentTpoPageState();
}

class _StudentTpoPageState extends State<StudentTpoPage> {

  @override
  Widget build(BuildContext context) {


    final student_button=  Container(
      margin: EdgeInsets.fromLTRB(10, 10, 10, 10),
      width: MediaQuery.of(context).size.width * 0.91,
      height: 55,
      child: ElevatedButton(

        onPressed: ()  {
          Navigator.push((context),
              MaterialPageRoute(builder: (context) => LoginPage()));
        },
        style: ElevatedButton.styleFrom(
          primary: AppColor.button_color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10  ),
          ),
          elevation: 15.0,
        ),
        child:  Text(
          "Student",
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );

    final tpo_button=  Container(
      margin: EdgeInsets.fromLTRB(10, 10, 10, 10),
      width: MediaQuery.of(context).size.width * 0.91,
      height: 55,
      child: ElevatedButton(

        onPressed: ()  {
          Navigator.push((context),
              MaterialPageRoute(builder: (context) => LoginTpoPage()));
        },
        style: ElevatedButton.styleFrom(
          primary: AppColor.button_color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10  ),
          ),
          elevation: 15.0,
        ),
        child:  Text(
          "TPO",
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );
    return Scaffold(

      body: SafeArea(
        child: Column(

          children: [

            Container(
              color: Colors.white,
              margin:   EdgeInsets.fromLTRB(20, 90, 20, 15),
              child:   Center(
                child: DefaultTextStyle(
                  style: TextStyle(fontSize:15,color: Colors.black,fontWeight: FontWeight.bold,fontStyle: FontStyle.normal),
                  child: Text(
                    'Smart Placement Assistant App',
                  ),
                ),
              ),
            ),

            SizedBox(height: 70,),
            student_button,
            tpo_button
          ],
        ),
      ),
    );
  }
}
