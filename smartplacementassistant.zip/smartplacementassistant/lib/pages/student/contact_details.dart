import 'dart:collection';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smartplacementassistant/models/contact__details_model.dart';

import '../../utilsapp/app_colors.dart';
import '../../utilsapp/app_constant.dart';
class ContactDetailsPage extends StatefulWidget {
  const ContactDetailsPage({Key? key}) : super(key: key);

  @override
  State<ContactDetailsPage> createState() => _ContactDetailsPageState();
}

class _ContactDetailsPageState extends State<ContactDetailsPage> {
  final _formAllKey = GlobalKey<FormState>();
  final _firstNameKey = GlobalKey<FormState>();
  final _lastNameKey = GlobalKey<FormState>();
  final _internKey = GlobalKey<FormState>();

  final parentsEmailEditingController = new TextEditingController();
  final contactEditingController = new TextEditingController();
  final parentsContactEditingController = new TextEditingController();
  final addressEditingController = new TextEditingController();


  int details_flag=0;

  bool isLoading=false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
   _getDetails();


  }

  @override
  Widget build(BuildContext context) {
    final submit_button=  Container(
      margin: EdgeInsets.fromLTRB(10, 10, 10, 10),
      width: MediaQuery.of(context).size.width * 0.91,
      height: 55,
      child: ElevatedButton(

        onPressed: ()  {
          details_flag ==0 ?  submitDetails(parentsEmailEditingController.text, contactEditingController.text,parentsContactEditingController.text,addressEditingController.text):
              updateDetails(parentsEmailEditingController.text, contactEditingController.text,parentsContactEditingController.text,addressEditingController.text);

        },
        style: ElevatedButton.styleFrom(
          primary: AppColor.button_color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10  ),
          ),
          elevation: 10.0,
        ),
        child:  Text(
         details_flag == 0 ? "Submit" : "Update",
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );

    final contactField =Form(  key: _firstNameKey,child: TextFormField(
        autofocus: false,

        controller: contactEditingController,
        keyboardType: TextInputType.number,
        validator: (value) {
          RegExp regex = new RegExp(r'^[0-9]{10}$');
          if (value!.isEmpty) {
            return ("contact cannot be Empty");
          }
          if (!regex.hasMatch(value)) {
            return ("Enter Valid contact(Min. 10 digits)");
          }

          return null;
        },
        onSaved: (value) {
          contactEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "Personal Contact Number",

          enabledBorder:   OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ))) ;

    final parentsEmailField = Form(  key: _formAllKey,child:TextFormField(
        autofocus: false,
        controller: parentsEmailEditingController,

        keyboardType: TextInputType.emailAddress,
        validator: (value) {
          RegExp regex = new RegExp(r'^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+.[a-z]$');
          if (value!.isEmpty) {
            return ("parents email cannot be Empty");
          }
          if (!regex.hasMatch(value)) {
            return ("Enter Valid Email");
          }

        },
        onSaved: (value) {
          parentsEmailEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "Parents Email",
       
          enabledBorder:   OutlineInputBorder(
            // width: 0.0 produces a thin "hairline" border
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        )) );

    final parentContactField =Form(   key: _lastNameKey,child: TextFormField(
        autofocus: false,

        controller:parentsContactEditingController ,
        keyboardType: TextInputType.number,
        validator: (value) {
          RegExp regex = new RegExp(r'^[0-9]{10}$');
          if (value!.isEmpty) {
            return ("contact cannot be Empty");
          }
          if (!regex.hasMatch(value)) {
            return ("Enter Valid contact(Min. 10 digits)");
          }
          return null;
        },
        onSaved: (value) {
          parentsContactEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "Parent Contact Number",
           enabledBorder:   OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ))) ;


    final addressField =Form(   key: _internKey,child: TextFormField(
        autofocus: false,

        controller:addressEditingController ,
        keyboardType: TextInputType.name,
        validator: (value) {
          RegExp regex = new RegExp(r'^.{3,}$');
          if (value!.isEmpty) {
            return ("address cannot be Empty");
          }

          return null;
        },
        onSaved: (value) {
          addressEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "Address details",
          hintText: "Enter complete address",
          enabledBorder:   OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ))) ;

    return Scaffold(

      appBar:AppBar(title: Text("Contact Details"),backgroundColor: AppColor.dashboard_color,),
      
      body: SafeArea(
        child: SingleChildScrollView(
          child: isLoading ==false ? Center(child: CircularProgressIndicator()) : Container(
            margin: EdgeInsets.fromLTRB(20, 20, 20, 20),
            child: Column(
           
           children: [
             
             parentsEmailField,
             SizedBox(height: 20,),
             contactField,
             SizedBox(height: 20,),
             parentContactField,
             SizedBox(height: 20,),
             addressField,
             SizedBox(height: 20,),
             submit_button
             
           ], 
          )
            ,),),
      ),
    );
  }

  Future<void> submitDetails(String parent_email, String contact_number, String parent_contact_number, String address) async {
    if (_formAllKey.currentState!.validate()&& _firstNameKey.currentState!.validate()
        && _lastNameKey.currentState!.validate()  && _internKey.currentState!.validate()) {
      DatabaseReference _dbref = FirebaseDatabase.instance.reference();

      ContactDetailsModel contactDetailsModel = new ContactDetailsModel();
      contactDetailsModel.parent_email = parent_email;
      contactDetailsModel.contact_number = contact_number;
      contactDetailsModel.parent_contact_number = parent_contact_number;
      contactDetailsModel.address = address;

      await _dbref.child(AppConstant.MAIN_TABLE).child(
          AppConstant.STUDENT_TABLE).child(
          FirebaseAuth.instance.currentUser!.uid).child(
          AppConstant.CONTACT_DETAILS_TABLE).get().then((value) =>
      {

        if(value.exists)
          {
            Fluttertoast.showToast(msg: "Details Already saved! ")
          }
        else
          {
            _dbref.child(AppConstant.MAIN_TABLE).child(
                AppConstant.STUDENT_TABLE).child(
                FirebaseAuth.instance.currentUser!.uid).child(
                AppConstant.CONTACT_DETAILS_TABLE)
                .set(contactDetailsModel.toMap())
                .whenComplete(() {
              Fluttertoast.showToast(msg: "Details submit successfully! ");
              Navigator.pop(context);
            }

            )
          }
      });
    }
  }

  _getDetails() async {

    DatabaseReference _dbref = FirebaseDatabase.instance.reference();

    await _dbref.child(AppConstant.MAIN_TABLE).child(
        AppConstant.STUDENT_TABLE).child(
        FirebaseAuth.instance.currentUser!.uid).child("contact_details").once().then((snapshot)   {
      isLoading=true;
      if(snapshot.exists)
        {
          setState((){
             details_flag=1;
              });

          print(snapshot.value.toString());
          print(snapshot.value["contact_number"].toString());

          parentsEmailEditingController.text=snapshot.value["parent_email"].toString();
          contactEditingController.text=snapshot.value["contact_number"].toString();
          parentsContactEditingController.text=snapshot.value["parent_contact_number"].toString();
          addressEditingController.text=snapshot.value["address"].toString();

      }
      else{
        setState((){
          details_flag=0;
        });
        Fluttertoast.showToast(msg: "Enter All the details! ");
      }
    });

  }

  updateDetails(String parent_email, String contact_number, String parent_contact_number, String address) async {
    DatabaseReference _dbref = FirebaseDatabase.instance.reference();

    ContactDetailsModel contactDetailsModel= new ContactDetailsModel();
    contactDetailsModel.parent_email=parent_email;
    contactDetailsModel.contact_number=contact_number;
    contactDetailsModel.parent_contact_number=parent_contact_number;
    contactDetailsModel.address=address;

    await _dbref.child(AppConstant.MAIN_TABLE).child(
        AppConstant.STUDENT_TABLE).child(
        FirebaseAuth.instance.currentUser!.uid).child(
        AppConstant.CONTACT_DETAILS_TABLE).get().then((value) => {


        _dbref.child(AppConstant.MAIN_TABLE).child(
            AppConstant.STUDENT_TABLE).child(
            FirebaseAuth.instance.currentUser!.uid).child(
            AppConstant.CONTACT_DETAILS_TABLE)
            .update(contactDetailsModel.toMap())
            .whenComplete(() {
          Fluttertoast.showToast(msg: "Details updated successfully! ");
          Navigator.pop(context);
        }

        )




    });

  }
}
