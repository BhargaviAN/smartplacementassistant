import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../../my_routes.dart';
import '../../utilsapp/app_colors.dart';
class ChangePasswordPage extends StatefulWidget {
  const ChangePasswordPage({Key? key}) : super(key: key);

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> {
  final _formAllKey = GlobalKey<FormState>();

  final noticeEditingController = new TextEditingController();
  @override
  Widget build(BuildContext context) {


    final submit_button=  Container(
      margin: EdgeInsets.fromLTRB(10, 10, 10, 10),
      width: MediaQuery.of(context).size.width * 0.91,
      height: 55,
      child: ElevatedButton(

        onPressed: ()  {
          changePassword(noticeEditingController.text);

        },
        style: ElevatedButton.styleFrom(
          primary: AppColor.button_color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10  ),
          ),
          elevation: 10.0,
        ),
        child:  Text(
          "Submit",
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );

    final noticeField = Form(  key: _formAllKey,child:TextFormField(
        autofocus: false,
        controller: noticeEditingController,

        keyboardType: TextInputType.text,
        validator: (value) {
          RegExp regex = new RegExp(r'^.{3,}$');
          if (value!.isEmpty) {
            return ("new password cannot be Empty");
          }

          return null;
        },
        onSaved: (value) {
          noticeEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "Change Password",
          enabledBorder:   OutlineInputBorder(
            // w
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        )) );
    return Scaffold(
      appBar:AppBar(title: Text("Change Password"),backgroundColor: AppColor.dashboard_color,),
      body: SafeArea(

        child: Container(
          margin: EdgeInsets.all(20),
          child: Column(

            children: [
              noticeField,
              SizedBox(height: 20,),
              submit_button,

            ],
          ),
        ),
      ),
    );
  }

  Future<void> changePassword(String newPassword) async {
    if (_formAllKey.currentState!.validate()) {

       await FirebaseAuth.instance.currentUser!.updatePassword(newPassword).then((_){
        print("Successfully changed password");
        Fluttertoast.showToast(msg: "Successfully changed password");
        Navigator.pushReplacementNamed(context, MyRoutes.loginRoute);
       }).catchError((error){
        print("Password can't be changed" + error.toString());
       });
    }

  }
}
