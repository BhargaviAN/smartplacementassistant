import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smartplacementassistant/pages/student_dashboard.dart';
import 'package:smartplacementassistant/utilsapp/app_constant.dart';

import '../../my_routes.dart';
import '../../utilsapp/app_colors.dart';
class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  bool isLoading=false;
  late String personalDetails="";
  late String academicDetails="";
  late String contactDetails="";
  @override
  void initState() {
     super.initState();

    _getDetails();
    _getAcademicDetails();
     _getContactDetails();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(title: Text("My Profile"),backgroundColor: AppColor.dashboard_color,),

      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            margin: EdgeInsets.fromLTRB(20, 20, 20, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              Text(AppConstant.name_string,style: TextStyle(color: AppColor.dashboard_color,fontSize: 18,fontWeight: FontWeight.bold),),
              Text(AppConstant.email_string,style: TextStyle(color: AppColor.dashboard_color),),

              SizedBox(height: 10,),
              Text("Personal Details ",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),),
              Text(personalDetails,style: TextStyle(color:AppColor.dashboard_color,fontSize: 16),),

              SizedBox(height: 10,),
              Text("Academic Details ",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),),
              Text(academicDetails,style: TextStyle(color:AppColor.dashboard_color,fontSize: 16),),

              SizedBox(height: 10,),
              Text("Contact Details ",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),),
              Text(contactDetails,style: TextStyle(color:AppColor.dashboard_color,fontSize: 16),),



            ],
          ),),
        ),
      ),
    );
  }

  _getDetails() async {

    DatabaseReference _dbref = FirebaseDatabase.instance.reference();

    await _dbref.child(AppConstant.MAIN_TABLE).child(
        AppConstant.STUDENT_TABLE).child(
        FirebaseAuth.instance.currentUser!.uid).child("personal_details").once().then((snapshot)   {

      isLoading=true;
      if(snapshot.exists)
      {


        print(snapshot.value.toString());



        setState((){
          personalDetails="University Seat No.: ${snapshot.value["universityseat_no"]}\nFull name : ${snapshot.value["first_name"]} ${snapshot.value["last_name"]}\nDOB : ${snapshot.value["dob"]}\nGender : ${snapshot.value["gender"]}";
        });


      }
      else{
        setState((){
          personalDetails="Personal Details not Found!";
        });

        Fluttertoast.showToast(msg: "Personal Details not Found! ");
      }
    });

  }

  _getAcademicDetails() async {

    DatabaseReference _dbref = FirebaseDatabase.instance.reference();

    await _dbref.child(AppConstant.MAIN_TABLE).child(
        AppConstant.STUDENT_TABLE).child(
        FirebaseAuth.instance.currentUser!.uid).child("academic_details").once().then((snapshot)   {

      isLoading=true;
      if(snapshot.exists)
      {






        setState((){
          academicDetails="10th % : "+snapshot.value["tenth_per"].toString()+
              "\n12th/Diploma % : "+snapshot.value["twel_per"].toString()
              + "\nDegree CGPA : " + snapshot.value["degree_cgpa"].toString()
              + "\nDepartment : " + snapshot.value["department"].toString();
        });


      }
      else{
        setState((){
          academicDetails="Academic Details not Found!";
        });
        Fluttertoast.showToast(msg: "Academic Details not Found! ");
      }
    });

  }

  _getContactDetails() async {

    DatabaseReference _dbref = FirebaseDatabase.instance.reference();

    await _dbref.child(AppConstant.MAIN_TABLE).child(
        AppConstant.STUDENT_TABLE).child(
        FirebaseAuth.instance.currentUser!.uid).child("contact_details").once().then((snapshot)   {

      isLoading=true;
      if(snapshot.exists)
      {






        setState((){
          contactDetails="Parent Email : "+snapshot.value["parent_email"].toString()+
              "\nContact Number : "+snapshot.value["contact_number"].toString()
              + "\nParent Contact Number : " + snapshot.value["parent_contact_number"].toString()
              + "\nAddress : " + snapshot.value["address"].toString();

        });


      }
      else{
        setState((){
          contactDetails="Contact Details not Found!";
        });
        Fluttertoast.showToast(msg: "Contact Details not Found! ");
      }
    });

  }
}
