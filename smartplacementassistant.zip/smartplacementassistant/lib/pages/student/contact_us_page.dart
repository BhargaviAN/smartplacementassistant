import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:url_launcher/url_launcher.dart' as UrlLauncher;
import '../../utilsapp/app_colors.dart';
class ContactUsPage extends StatefulWidget {
  const ContactUsPage({Key? key}) : super(key: key);

  @override
  State<ContactUsPage> createState() => _ContactUsPageState();
}

class _ContactUsPageState extends State<ContactUsPage> {

  String? encodeQueryParameters(Map<String, String> params) {
    return params.entries
        .map((MapEntry<String, String> e) =>
    '${Uri.encodeComponent(e.key)}=${Uri.encodeComponent(e.value)}')
        .join('&');
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(title: Text("Contact Us"),backgroundColor: AppColor.dashboard_color,),
        body: SafeArea(
        child: SingleChildScrollView(
          child: Container(

            child:Column(
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Container(
                    margin:   EdgeInsets.fromLTRB(20, 20, 20, 5),
                    child:   Text(
                      'Any query? Feel free to contact us.',
                      style: TextStyle(fontSize:17,color: Colors.black,fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                InkWell(
                  onTap: (){
                    _makePhoneCall("8105800726");
                  },
                  child: Container(
                      color: AppColor.dashboard_color,
                      margin: EdgeInsets.fromLTRB(20, 20, 20, 0),
                      child: Padding(
                        padding:EdgeInsets.all(10) ,
                        child:Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Icon(Icons.call,color: Colors.white,),
                            GestureDetector(
                              child:  Text("8105800726",style: TextStyle(color: Colors.white),),
                              onTap: () {
                                Clipboard.setData( ClipboardData(text: "8105800726"));
                                Fluttertoast.showToast(msg: 'Phone number Copied!');
                              },
                            ),
                            Text(""),
                           ],
                        ),
                      )
                  ),
                ),
                InkWell(
                  onTap: (){

                    final Uri emailLaunchUri = Uri(
                      scheme: 'mailto',
                      path: 'teamspaa39@gmail.com',
                      query: encodeQueryParameters(<String, String>{
                        'subject': 'Write your query!',
                      }),
                    );

                    launchUrl(emailLaunchUri);
                  },
                  child: Container(
                      color: AppColor.dashboard_color,
                      margin: EdgeInsets.fromLTRB(20, 20, 20, 0),
                      child: Padding(
                        padding:EdgeInsets.all(10) ,
                        child:Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Icon(Icons.email,color: Colors.white,),
                             GestureDetector(
                              child:  Text("teamspaa39@gmail.com",style: TextStyle(color: Colors.white),),
                              onTap: () {
                                Clipboard.setData(new ClipboardData(text: "teamspaa39@gmail.com"));
                                Fluttertoast.showToast(msg: 'email Copied!');
                              },
                            ),

                            Text(""),
                           ],
                        ),
                      )
                  ),
                ),

              ],
            ),
          ),
    ),),

    );
  }

  Future<void> _makePhoneCall(String phoneNumber) async {
    final Uri launchUri = Uri(
      scheme: 'tel',
      path: phoneNumber,
    );
    await launchUrl(launchUri);
  }
}
