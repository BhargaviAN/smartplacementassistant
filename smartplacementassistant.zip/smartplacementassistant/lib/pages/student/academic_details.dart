import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smartplacementassistant/models/academic_details_model.dart';

import '../../utilsapp/app_colors.dart';
import '../../utilsapp/app_constant.dart';
class AcademicDetailsPage extends StatefulWidget {
  const AcademicDetailsPage({Key? key}) : super(key: key);

  @override
  State<AcademicDetailsPage> createState() => _AcademicDetailsPageState();
}

class _AcademicDetailsPageState extends State<AcademicDetailsPage> {

  final _formAllKey = GlobalKey<FormState>();
  final _firstNameKey = GlobalKey<FormState>();
  final _lastNameKey = GlobalKey<FormState>();
  final _backlogsKey = GlobalKey<FormState>();

  final tenthEditingController = new TextEditingController();
  final twelthEditingController = new TextEditingController();
  final degreeEditingController = new TextEditingController();
  final backlogsEditingController = new TextEditingController();

  int details_flag=0;

  var isLoading=false;

  String dropdownvalue = 'Artificial Intelligence and Machine Learning';
  var cgpaitems =["9.5","9.0","8.5","8.0","7.5","7.0","6.5","6.0"];

  var items = [
    'Artificial Intelligence and Machine Learning',
    'Biotechnology Engineering',
    'Computer Science and Engineering',
    'Electronics and Communication Engineering',
    'Civil Engineering',
    'Information Science and Engineering',
    'Electrical and Electronics Engineering',
    'Industrial Production Engineering',
    'Mechanical Engineering',
    'Electrical and Instrumentation Engineering',
    'Automobile Engineering',
  ];

  String department="";


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
     _getDetails();


  }
  @override
  Widget build(BuildContext context) {
    final submit_button=  Container(
      margin: EdgeInsets.fromLTRB(10, 10, 10, 10),
      width: MediaQuery.of(context).size.width * 0.91,
      height: 55,
      child: ElevatedButton(

        onPressed: ()  {
         details_flag ==0 ? submitDetails(tenthEditingController.text, twelthEditingController.text,degreeEditingController.text,backlogsEditingController.text,dropdownvalue) :
           updateDetails(tenthEditingController.text, twelthEditingController.text,degreeEditingController.text,backlogsEditingController.text,dropdownvalue);

        },
        style: ElevatedButton.styleFrom(
          primary: AppColor.button_color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10  ),
          ),
          elevation: 10.0,
        ),
        child:  Text(
          details_flag == 0 ? "Submit" : "Update" ,
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );

    final tenthField = Form(  key: _formAllKey,child:TextFormField(
        autofocus: false,
        controller: tenthEditingController,

        keyboardType: TextInputType.numberWithOptions(decimal: true),
        validator: (value) {
          RegExp xp = new RegExp(r'[0-9]$');
          if (value!.isEmpty) {
            return ("10th cannot be Empty");
          }
          if (!xp.hasMatch(value)) {
            return ("Enter Valid % or CGPA (Min. 1 Character)");
          }

        },
        onSaved: (value) {
          tenthEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "10th % or CGPA",

          enabledBorder:   OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        )) );
    final twelvthField =Form(  key: _firstNameKey,child: TextFormField(
        autofocus: false,

        controller: twelthEditingController,
        keyboardType: TextInputType.numberWithOptions(decimal: true),
        validator: (value) {
          RegExp tp = new RegExp(r'[0-9]$');
          if (value!.isEmpty) {
            return ("12th/Diploma cannot be Empty");
          }
          if (!tp.hasMatch(value)) {
            return ("Enter Valid % (Min. 1 Character)");
          }


        },
        onSaved: (value) {
          twelthEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "12th/Diploma %",

          enabledBorder:   OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ))) ;
    final degreeField =Form(   key: _lastNameKey,child: TextFormField(
        autofocus: false,

        controller:degreeEditingController ,
        keyboardType: TextInputType.numberWithOptions(decimal: true),
        validator: (value) {
          RegExp dp = new RegExp(r'[0-9]$');
          if (value!.isEmpty) {
            return ("degree cannot be Empty");
          }
          if (!dp.hasMatch(value)) {
            return ("Enter Valid CGPA (Min. 1 Character)");
          }


        },
        onSaved: (value) {
          degreeEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "Degree CGPA",
          hintText: "9.5,9.0,8.5,8.0,7.5,7.0,6.5,6.0",
          hintStyle: TextStyle(fontSize: 10),

          enabledBorder:   OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ))) ;


    final backlogsField =Form(   key: _backlogsKey,child: TextFormField(
        autofocus: false,

        controller:backlogsEditingController ,
        keyboardType: TextInputType.number,
        validator: (value) {
          RegExp bl = new RegExp(r'[0-9]$');
          if (value!.isEmpty) {
            return ("backlogs cannot be empty or enter zero if not any");
          }
          if (!bl.hasMatch(value)) {
            return ("Enter valid no. of backlogs (Min. 1 Character) ");
          }

        },
        onSaved: (value) {
          backlogsEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "Backlogs (current)",

          enabledBorder:   OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ))) ;




    return Scaffold(
      appBar:AppBar(title: Text("Academic Details"),backgroundColor: AppColor.dashboard_color,),
      body: SafeArea(
        child: SingleChildScrollView(
          child: isLoading ==false ? Center(child: CircularProgressIndicator()) :  Container(
            margin: EdgeInsets.fromLTRB(20, 20, 20, 20),
            child: Column(
              children: [
                tenthField,
                SizedBox(height: 20,),
                twelvthField,
                SizedBox(height: 20,),
                degreeField,

                SizedBox(height: 20,),
                backlogsField,

                SizedBox(height: 20,),
                Text(
                  "Choose your department:",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 15, color: Colors.black, fontWeight: FontWeight.bold),
                ),
                DropdownButton(
                  style: TextStyle(fontSize: 13,color: Colors.black),
                  value: dropdownvalue,
                  hint: Text("Select Department"),
                  menuMaxHeight: 250,
                  // Down Arrow Icon
                  icon:  Icon(Icons.keyboard_arrow_down),

                  items: items.map((String items) {
                    return DropdownMenuItem(
                      value: items,
                      child: Text(items),
                    );
                  }).toList(),

                  onChanged: (String? newValue) {
                    setState(() {
                      dropdownvalue = newValue!;
                    });
                  },
                ),
                SizedBox(height: 10,),

                Text(
                  "Your Department : $department" ,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 15, color: Colors.black, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 20,),
                submit_button,
              ],
            ),
          ),
        ),
      ),

    );
  }

  Future<void> submitDetails(String tenthper, String twel_per, String degree_cgpa, String backlogs, String department) async {

    if (_formAllKey.currentState!.validate()&& _firstNameKey.currentState!.validate()
        && _lastNameKey.currentState!.validate()  && _backlogsKey.currentState!.validate()) {
      DatabaseReference _dbref = FirebaseDatabase.instance.reference();


      AcademicDetailsModel academicDetailsModel = AcademicDetailsModel();

      academicDetailsModel.tenth_per = tenthper;
      academicDetailsModel.twel_per = twel_per;
      academicDetailsModel.degree_cgpa = degree_cgpa;
      academicDetailsModel.backlogs = backlogs;
      academicDetailsModel.department = department;


      await _dbref.child(AppConstant.MAIN_TABLE).child(
          AppConstant.STUDENT_TABLE).child(
          FirebaseAuth.instance.currentUser!.uid).child(
          AppConstant.ACADEMIC_DETAILS_TABLE).once().then((value) =>
      {

        if(value.exists)
          {
            Fluttertoast.showToast(msg: "Details Already saved! ")
          }
        else
          {
            _dbref.child(AppConstant.MAIN_TABLE).child(
                AppConstant.STUDENT_TABLE).child(
                FirebaseAuth.instance.currentUser!.uid).child(
                AppConstant.ACADEMIC_DETAILS_TABLE)
                .set(academicDetailsModel.toMap())
                .whenComplete(() {
              _dbref.child(AppConstant.MAIN_TABLE).child(
                  AppConstant.STUDENT_TABLE).child(
                  FirebaseAuth.instance.currentUser!.uid).update(
                  {"department": department});
              _dbref.child(AppConstant.MAIN_TABLE).child(
                  AppConstant.STUDENT_TABLE).child(
                  FirebaseAuth.instance.currentUser!.uid).update(
                  {"cgpa": degree_cgpa});
              Fluttertoast.showToast(msg: "Details submit successfully! ");
              Navigator.pop(context);
            }

            )
          }
      });
    }

  }

  _getDetails() async {

    DatabaseReference _dbref = FirebaseDatabase.instance.reference();

    await _dbref.child(AppConstant.MAIN_TABLE).child(
        AppConstant.STUDENT_TABLE).child(
        FirebaseAuth.instance.currentUser!.uid).child("academic_details").once().then((snapshot)   {
      setState((){
        isLoading=true;
      });
      if(snapshot.exists)
      {
        setState((){
          details_flag=1;
        });

        print(snapshot.value.toString());

        tenthEditingController.text=snapshot.value["tenth_per"].toString();
        twelthEditingController.text=snapshot.value["twel_per"].toString();
        degreeEditingController.text=snapshot.value["degree_cgpa"].toString();
        backlogsEditingController.text=snapshot.value["backlogs"].toString();
        department =snapshot.value["department"].toString();
        dropdownvalue =snapshot.value["department"].toString();

      }
      else{
        setState((){
          details_flag=0;
        });
        Fluttertoast.showToast(msg: "Enter All the details! ");
      }
    });

  }


  Future<void> updateDetails(String tenthper, String twel_per, String degree_cgpa, String backlogs, String department) async {

    DatabaseReference _dbref = FirebaseDatabase.instance.reference();


    AcademicDetailsModel academicDetailsModel = AcademicDetailsModel();

    academicDetailsModel.tenth_per = tenthper;
    academicDetailsModel.twel_per = twel_per;
    academicDetailsModel.degree_cgpa = degree_cgpa;
    academicDetailsModel.backlogs = backlogs;
    academicDetailsModel.department = department;



    await _dbref.child(AppConstant.MAIN_TABLE).child(
        AppConstant.STUDENT_TABLE).child(
        FirebaseAuth.instance.currentUser!.uid).child(
        AppConstant.ACADEMIC_DETAILS_TABLE).once().then((value) => {


        _dbref.child(AppConstant.MAIN_TABLE).child(
            AppConstant.STUDENT_TABLE).child(
            FirebaseAuth.instance.currentUser!.uid).child(
            AppConstant.ACADEMIC_DETAILS_TABLE)
            .update(academicDetailsModel.toMap())
            .whenComplete(() {

          _dbref.child(AppConstant.MAIN_TABLE).child(
              AppConstant.STUDENT_TABLE).child(
              FirebaseAuth.instance.currentUser!.uid).update({"department" : department});  _dbref.child(AppConstant.MAIN_TABLE).child(
              AppConstant.STUDENT_TABLE).child(
              FirebaseAuth.instance.currentUser!.uid).update({"cgpa" : degree_cgpa});

          Fluttertoast.showToast(msg: "Details updated successfully! ");
          Navigator.pop(context);
        }

        )



    });

  }
}
