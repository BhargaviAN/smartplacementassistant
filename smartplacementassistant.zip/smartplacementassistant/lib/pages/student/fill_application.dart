import 'package:flutter/material.dart';
import 'package:smartplacementassistant/utilsapp/app_colors.dart';

import '../../my_routes.dart';
class FillApplicationPage extends StatefulWidget {
  const FillApplicationPage({Key? key}) : super(key: key);

  @override
  State<FillApplicationPage> createState() => _FillApplicationPageState();
}

class _FillApplicationPageState extends State<FillApplicationPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(title: Text("Fill Application"),backgroundColor: AppColor.dashboard_color,),
      body: SafeArea(
        child: SingleChildScrollView(
            child: Column(

              children: [

                //personal details
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, MyRoutes.personalDetailsRoute);
                  },
                  child: Container(
                    color: AppColor.dashboard_color,
                    margin: EdgeInsets.fromLTRB(20, 20, 20, 0),
                    child: Padding(
                      padding:EdgeInsets.all(10) ,
                      child:Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Icon(Icons.perm_contact_cal_sharp,color: Colors.white,),
                          Text("Personal Details",style: TextStyle(color: Colors.white),),
                          Icon(Icons.arrow_forward_ios_outlined,color: Colors.white,),
                        ],
                      ),
                    )
                  ),
                ),

                //Academic details
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, MyRoutes.academicDetailsRoute);
                  },
                  child: Container(
                    color: AppColor.dashboard_color,
                    margin: EdgeInsets.fromLTRB(20, 20, 20, 0),
                    child: Padding(
                      padding:EdgeInsets.all(10) ,
                      child:Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Icon(Icons.cast_for_education,color: Colors.white,),
                          Text("Academic Details",style: TextStyle(color: Colors.white),),
                          Icon(Icons.arrow_forward_ios_outlined,color: Colors.white,),
                        ],
                      ),
                    )
                  ),
                ),

                //Contact details
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, MyRoutes.contactDetailsRoute);
                  },
                  child: Container(
                    color: AppColor.dashboard_color,
                    margin: EdgeInsets.fromLTRB(20, 20, 20, 0),
                    child: Padding(
                      padding:EdgeInsets.all(10) ,
                      child:Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Icon(Icons.call,color: Colors.white,),
                          Text("Contact Details",style: TextStyle(color: Colors.white),),
                          Icon(Icons.arrow_forward_ios_outlined,color: Colors.white,),
                        ],
                      ),
                    )
                  ),
                ),




              ],
            ),
        ),
      ),
    );
  }
}
