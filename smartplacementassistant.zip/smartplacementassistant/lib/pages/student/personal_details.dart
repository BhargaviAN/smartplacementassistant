 import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:smartplacementassistant/models/personal_details_model.dart';
import 'package:smartplacementassistant/pages/student/fill_application.dart';

import '../../utilsapp/app_colors.dart';
import '../../utilsapp/app_constant.dart';
class PersonalDetailsPage extends StatefulWidget {
  const PersonalDetailsPage({Key? key}) : super(key: key);

  @override
  State<PersonalDetailsPage> createState() => _PersonalDetailsPageState();
}

class _PersonalDetailsPageState extends State<PersonalDetailsPage> {
  final _formAllKey = GlobalKey<FormState>();
  final _firstNameKey = GlobalKey<FormState>();
  final _middleNameKey = GlobalKey<FormState>();
  final _lastNameKey = GlobalKey<FormState>();

  final usnEditingController = new TextEditingController();
  final firstNameEditingController = new TextEditingController();
  final middleNameEditingController = new TextEditingController();
  final lastNameEditingController = new TextEditingController();

  static String gender="male";
  static String dob="";
  TextEditingController dateinput = TextEditingController();

  int details_flag=0;

  bool isLoading=false;

  @override
  void initState() {
    dateinput.text = "";
    super.initState();

    _getDetails();
  }

  @override
  Widget build(BuildContext context) {

    final submit_button=  Container(
      margin: EdgeInsets.fromLTRB(10, 10, 10, 10),
      width: MediaQuery.of(context).size.width * 0.91,
      height: 55,
      child: ElevatedButton(

        onPressed: ()  {
        details_flag ==0 ?  submitDetails(usnEditingController.text, firstNameEditingController.text,middleNameEditingController.text,lastNameEditingController.text,dateinput.text,gender)
          : updateDetails(usnEditingController.text, firstNameEditingController.text,middleNameEditingController.text,lastNameEditingController.text,dateinput.text,gender);

        },
        style: ElevatedButton.styleFrom(
          primary: AppColor.button_color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10  ),
          ),
          elevation: 10.0,
        ),
        child:  Text(
          details_flag ==0 ?   "Submit" : "Update",
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );

    final usnField = Form(  key: _formAllKey,child:TextFormField(
        autofocus: false,
        controller: usnEditingController,

        keyboardType: TextInputType.name,
        validator: (value) {
          RegExp regex = new RegExp(r'^(2ba|2bA|2BA|2Ba)[0-9]{2}[a-zA-Z]{2}[0-9]{3}$');
          if (value!.isEmpty) {
            return ("University seat no. cannot be Empty");
          }
           if (!regex.hasMatch(value)) {
            return ("Enter Valid USN");
          }

        },

        onSaved: (value) {
          usnEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "University Seat No.",
          enabledBorder:   OutlineInputBorder(
            // width: 0.0 produces a thin "hairline" border
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        )) );
    final firstNameField =Form(  key: _firstNameKey,child: TextFormField(
        autofocus: false,

        controller: firstNameEditingController,
        keyboardType: TextInputType.name,
        validator: (value) {
          RegExp fn = new RegExp(r'[A-Za-z]$');
          if (value!.isEmpty) {
            return ("First Name cannot be Empty");
          }
          if (!fn.hasMatch(value)) {
            return ("Enter Valid name(Min. 3 Characters)");
          }
        },
        onSaved: (value) {
          firstNameEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "First Name",
          enabledBorder:   OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ))) ;
    final middleNameField= Form(  key: _middleNameKey,child: TextFormField(
        autofocus: false,

        controller: middleNameEditingController,
        keyboardType: TextInputType.name,
        validator: (value) {
          RegExp mn = new RegExp(r'" "|[A-Za-z]$');
          if (value!.isEmpty) {
            return (" ");
          }
          if (!mn.hasMatch(value)) {
            return ("Enter Valid Name (Min. 1 Character)");
          }

        },
        onSaved: (value) {
          middleNameEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "Middle Name",
          enabledBorder:   OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ))) ;
    final lastNameField =Form(   key: _lastNameKey,child: TextFormField(
        autofocus: false,

        controller:lastNameEditingController ,
        keyboardType: TextInputType.name,
        validator: (value) {
          RegExp ln = new RegExp(r'[A-Za-z]$');
          if (value!.isEmpty) {
            return ("last Name cannot be Empty");
          }
          if (!ln.hasMatch(value)) {
            return ("Enter Valid Name (Min. 3 Characters)");
          }

        },
        onSaved: (value) {
          lastNameEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          filled: true,
          fillColor: AppColor.textfieldColor,
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          labelText: "Last Name",
          enabledBorder:   OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white, width: 0.0),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ))) ;

    return Scaffold(
      appBar:AppBar(title: Text("Personal Details"),backgroundColor: AppColor.dashboard_color,),
      body: SafeArea(
        child: SingleChildScrollView(
          child: isLoading ==false ? Center(child: CircularProgressIndicator()) :  Container(
            margin: EdgeInsets.fromLTRB(20, 20, 20, 20),
            child: Column(

              children: [
                usnField,
                SizedBox(height: 20,),
                firstNameField,
                SizedBox(height: 20,),
                middleNameField,
                SizedBox(height: 20,),
                lastNameField,


            Container(
              padding: EdgeInsets.all(15),
               height:90,
            child:Center(
            child:TextField(
            controller: dateinput,
              decoration: InputDecoration(
              icon: Icon(Icons.calendar_today),
              labelText: "Select Date of Birth"
                                 ),
             readOnly: true,
             onTap: () async {
                 DateTime? pickedDate = await showDatePicker(
                 context: context, initialDate: DateTime.now(),
                firstDate: DateTime(1990),
             lastDate: DateTime(2101)
             );

              if(pickedDate != null ){
                print(pickedDate);
               String formattedDate = DateFormat('yyyy-MM-dd').format(pickedDate);
                 print(formattedDate);
                   setState(() {
                  dateinput.text = formattedDate;
                    });
                    }else{
                      print("Date is not selected");
                        }},)),),


    Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
    const Text('Please select gender:'),
    ListTile(
    leading: Radio<String>(
    value: 'male',
    groupValue: gender,
    onChanged: (value) {
    setState(() {
    gender = value!;
    });
    },
    ),
    title: const Text('Male'),
    ),
    ListTile(
    leading: Radio<String>(
    value: 'female',
    groupValue: gender,
    onChanged: (value) {
    setState(() {
    gender = value!;
    });
    },
    ),
    title: const Text('Female'),
    ),
    ]
    ),

                submit_button,



              ],
            ),
          ),
        ),
      ),
    );
  }

   void submitDetails(String usn, String firstName, String middleName, String lastName, String dob, String gender) async {

    if (_formAllKey.currentState!.validate()&& _firstNameKey.currentState!.validate()
        &&_middleNameKey.currentState!.validate()&& _lastNameKey.currentState!.validate()) {
      DatabaseReference _dbref = FirebaseDatabase.instance.reference();


      PersonalDetailsModel personalDetailsModel = PersonalDetailsModel();

      // writing all the values
      personalDetailsModel.universityseat_no = usn;
      personalDetailsModel.first_name = firstName;
      personalDetailsModel.middle_name=middleName;
      personalDetailsModel.last_name = lastName;
      personalDetailsModel.dob = dob;
      personalDetailsModel.gender = gender;


      await _dbref.child(AppConstant.MAIN_TABLE).child(
          AppConstant.STUDENT_TABLE).child(
          FirebaseAuth.instance.currentUser!.uid).child(
          AppConstant.PERSONAL_DETAILS_TABLE).once().then((value) => {

            if(value.exists)
              {
                   Fluttertoast.showToast(msg: "Details Already saved! ")
              }
            else{
          _dbref.child(AppConstant.MAIN_TABLE).child(
          AppConstant.STUDENT_TABLE).child(
          FirebaseAuth.instance.currentUser!.uid).child(
          AppConstant.PERSONAL_DETAILS_TABLE)
          .set(personalDetailsModel.toMap())
          .whenComplete(() {
        Fluttertoast.showToast(msg: "Details submit successfully! ");
        Navigator.pop(context);
      }

      )



            }
      });

    }
    else{
      Fluttertoast.showToast(msg: "Enter All data! ");
    }
  }




  _getDetails() async {

    DatabaseReference _dbref = FirebaseDatabase.instance.reference();

    await _dbref.child(AppConstant.MAIN_TABLE).child(
        AppConstant.STUDENT_TABLE).child(
        FirebaseAuth.instance.currentUser!.uid).child("personal_details").once().then((snapshot)   {

          isLoading=true;
      if(snapshot.exists)
      {
        setState((){
          details_flag=1;
        });

        print(snapshot.value.toString());

        usnEditingController.text=snapshot.value["universityseat_no"].toString();
        firstNameEditingController.text=snapshot.value["first_name"].toString();
        middleNameEditingController.text=snapshot.value["middle_name"].toString();
        lastNameEditingController.text=snapshot.value["last_name"].toString();
        dateinput.text=snapshot.value["dob"].toString();
        if(snapshot.value["gender"].toString()=="male")
          {
           setState((){
             gender ="male";
           });
          }else{
          setState((){
            gender ="female";
          });
        }

      }
      else{
        setState((){
          details_flag=0;
        });
        Fluttertoast.showToast(msg: "Enter All the details! ");
      }
    });

  }

  void updateDetails(String usn, String firstName, String middleName, String lastName, String dob, String gender) async {

    if (_formAllKey.currentState!.validate()&& _firstNameKey.currentState!.validate()&& _middleNameKey.currentState!.validate()&& _lastNameKey.currentState!.validate()) {
      DatabaseReference _dbref = FirebaseDatabase.instance.reference();


      PersonalDetailsModel personalDetailsModel = PersonalDetailsModel();

      // writing all the values
      personalDetailsModel.universityseat_no = usn;
      personalDetailsModel.first_name = firstName;
      personalDetailsModel.middle_name=middleName;
      personalDetailsModel.last_name = lastName;
      personalDetailsModel.dob = dob;
      personalDetailsModel.gender = gender;


      await _dbref.child(AppConstant.MAIN_TABLE).child(
              AppConstant.STUDENT_TABLE).child(
              FirebaseAuth.instance.currentUser!.uid).child(
              AppConstant.PERSONAL_DETAILS_TABLE)
              .update(personalDetailsModel.toMap())
              .whenComplete(() {
            Fluttertoast.showToast(msg: "Details updated successfully! ");
            Navigator.pop(context);
          }

          );





    }
    else{
      Fluttertoast.showToast(msg: "Enter All data! ");
    }
  }
  
}
