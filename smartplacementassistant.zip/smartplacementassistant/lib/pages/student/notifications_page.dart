import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smartplacementassistant/models/notification_model.dart';

import '../../utilsapp/app_colors.dart';
import '../../utilsapp/app_constant.dart';
class NotificationsPage extends StatefulWidget {
  const NotificationsPage({Key? key}) : super(key: key);

  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {


  List<NotificationModel> notificationList=[];



  late DatabaseReference _dbref;
  bool isLoading=false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _dbref = FirebaseDatabase.instance.reference();

    getData();
  }

  Future<void> getData()
  async {
    await _dbref.child(AppConstant.MAIN_TABLE).child(AppConstant.STUDENT_TABLE).child(
        FirebaseAuth.instance.currentUser!.uid).child("notifications").once()
        .then((snapshot) {
      print("valueupdate " + snapshot.value.toString());

      if (snapshot.exists) {
        Map<dynamic, dynamic> values = snapshot.value;
        values.forEach((key,values) {

          print(values["notification_text"]);



          setState((){
            isLoading=true;

            NotificationModel userModel= new NotificationModel();
            userModel.id =values["id"];
            userModel.notification_text=values["notification_text"];

            notificationList.add(userModel);

            notificationList=notificationList.reversed.toList();
          });


        });

      } else {
        isLoading=true;
        Fluttertoast.showToast(msg: 'Data not found!');
      }

    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar:AppBar(title: Text("Notifications"),backgroundColor: AppColor.dashboard_color,),

      body: isLoading==false ? Center(child: CircularProgressIndicator(),)  :  Column(
        children: notificationList.map((userone){
          return Container(
            
            child: ListTile(
              title: Text(userone.notification_text.toString()),
            ),
            margin: EdgeInsets.fromLTRB(15, 10, 15, 0),
            padding: EdgeInsets.all(5),
            color: Colors.blueGrey[100],
          );
        }).toList(),
      ),

    );
  }
}
