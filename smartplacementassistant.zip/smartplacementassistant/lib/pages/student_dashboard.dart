import 'package:carousel_slider/carousel_slider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smartplacementassistant/models/notice_model.dart';
import 'package:smartplacementassistant/pages/login_page.dart';
import 'package:smartplacementassistant/pages/student/notifications_page.dart';
import 'package:smartplacementassistant/utilsapp/app_colors.dart';

import '../my_routes.dart';
import '../utilsapp/app_constant.dart';
class StudentDashboard extends StatefulWidget {
  const StudentDashboard({Key? key}) : super(key: key);

  @override
  State<StudentDashboard> createState() => _StudentDashboardState();
}

class _StudentDashboardState extends State<StudentDashboard> {
  
    String name="",email="";

  late DatabaseReference _dbref;
  bool isLoading=false;
  bool isNoticeLoading=false;
    int _current = 0;
    final CarouselController _controller = CarouselController();
  List<NoticeModel> noticeModelList=[];
    final List<String> imgList = ["one.jpeg","two.jpg","three.jpeg","four.jpg","five.jpeg"];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _dbref = FirebaseDatabase.instance.reference();

    getStudentData();

    getNoticeData();
  }
  
  Future<void> getStudentData()
  async {
    await _dbref.child(AppConstant.MAIN_TABLE).child(AppConstant.STUDENT_TABLE)
        .orderByChild("uid").equalTo(FirebaseAuth.instance.currentUser!.uid).once()
        .then((snapshot) {
      print("valueupdate " + snapshot.value.toString());

      if (snapshot.exists) {
        Map<dynamic, dynamic> values = snapshot.value;
        values.forEach((key,values) {

          print(values["name"]);
         
            print(values["email"].toString());
           
           setState((){
             isLoading=true;
             name=values["name"];
             email=values["email"];

             AppConstant.name_string=values["name"];
             AppConstant.email_string=values["email"];
           });
          

        });

      } else {
        isLoading=true;
        Fluttertoast.showToast(msg: 'Data not found!');
      }

    });
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Home",style: TextStyle(
          color: Colors.white
        ),),
        backgroundColor: AppColor.dashboard_color,
      actions: [
        /*InkWell(
          onTap: (){

            getNoticeData();

          },
          child: Padding(
              padding: EdgeInsets.fromLTRB(0, 0, 10, 0),
              child: Icon(Icons.refresh,color: Colors.white,)),
        ),*/
        InkWell(
          onTap: (){
          Navigator.push(context,  MaterialPageRoute<dynamic>(
            builder: (BuildContext context) => NotificationsPage(),
          ));


          },
          child: Padding(
              padding: EdgeInsets.fromLTRB(0, 0, 10, 0),
              child: Icon(Icons.notifications_active,color: Colors.white,)),
        ),
        InkWell(
          onTap: (){
            FirebaseAuth.instance.signOut();
            Navigator.pushAndRemoveUntil<dynamic>(
              context,
              MaterialPageRoute<dynamic>(
                builder: (BuildContext context) => LoginPage(),
              ),
                  (route) => false,//if you want to disable back feature set to false
            );
            Fluttertoast.showToast(msg: 'Logout successfully');
          },
          child: Padding(
              padding: EdgeInsets.fromLTRB(0, 0, 10, 0),
              child: Icon(Icons.logout,color: Colors.white,)),
        ),
      ],
      ),
      body:SafeArea(

        child: SingleChildScrollView(
          child:Column(


            children: [

              CarouselSlider(
                carouselController: _controller,
                options: CarouselOptions(
                    autoPlay: true,
                    enlargeCenterPage: true,
                    aspectRatio: 2.0,
                    onPageChanged: (index, reason) {
                      setState(() {
                        _current = index;
                      });
                    }),
                items: imgList
                    .map((item) => Container(
                  child: Center(
                      child:
                      Image.asset("assets/images/$item", fit: BoxFit.cover, width: 1000)),
                ))
                    .toList(),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: imgList.asMap().entries.map((entry) {
                  return GestureDetector(
                    onTap: () => _controller.animateToPage(entry.key),
                    child: Container(
                      width: 12.0,
                      height: 12.0,
                      margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: (Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black)
                              .withOpacity(_current == entry.key ? 0.9 : 0.4)),
                    ),
                  );
                }).toList(),
              ),
              Padding(
                padding: EdgeInsets.all(15),
                child: Center(child:     Text("Notice List",style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.bold,
                ),) ,),
              ),


              isNoticeLoading ==false?  Column(
                children: [
                  SizedBox(height: 100,),

                  Center(child:     Text("No notice yet!") ,),

                  CircularProgressIndicator(),],
              ):  Column(
                children: noticeModelList.map((userone){
                  return Container(
                    child: ListTile(
                      title: Text(userone.notice.toString()),
                    ),
                    margin: EdgeInsets.fromLTRB(15, 10, 15, 0),
                    padding: EdgeInsets.all(5),
                    color: Colors.blueGrey[100],
                  );
                }).toList(),
              ),


            ],
          ) ,



        ),
      ) ,

      drawer: Drawer(
      child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: <Widget>[
            UserAccountsDrawerHeader(
              decoration: BoxDecoration(
                color: AppColor.dashboard_color,
              ),
              accountName: Text(isLoading ? name : " loading...",style: TextStyle(color: Colors.white),),
              accountEmail: Text(isLoading ? email: "",style: TextStyle(color: Colors.white),),
               currentAccountPicture: CircleAvatar(
                backgroundColor: Colors.orangeAccent,
                child: Text(
               isLoading ? name.substring(0,1) : " ",
                  style: TextStyle(fontSize: 40.0),
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home,), title: Text("Home"),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(Icons.account_circle_outlined), title: Text("Profile"),
              onTap: () {

                Navigator.pop(context);
                Navigator.pushNamed(context, MyRoutes.profileRoute);
                },
            ),
            ListTile(
              leading: Icon(Icons.account_balance_wallet_rounded), title: Text("Fill Application"),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, MyRoutes.fillApplicationRoute);

              },
            ),  ListTile(
              leading: Icon(Icons.password), title: Text("Change Password"),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, MyRoutes.changePasswordRoute);

              },
            ), ListTile(
              leading: Icon(Icons.contact_mail), title: Text("Contact Us"),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, MyRoutes.contactUsRoute);

              },
            ),
          ],
        ),

    ),
    );
  }



    Future<void> getNoticeData()
    async {
      await _dbref.child("notice").once()
          .then((snapshot) {
        print("saasd " + snapshot.value.toString());
        if(noticeModelList.isNotEmpty) noticeModelList.clear();
        if (snapshot.exists) {
          Map<dynamic, dynamic> values = snapshot.value;
          values.forEach((key,values) {


            setState((){
              isNoticeLoading=true;

              NoticeModel userModel= new NoticeModel();
              userModel.id=values["id"];
              userModel.notice=values["notice"];

              noticeModelList.add(userModel);
              noticeModelList= noticeModelList.reversed.toList();
            });


          });

        } else {
          isNoticeLoading=true;
          Fluttertoast.showToast(msg: 'Data not found!');
        }

      });
    }


}
