import 'dart:async';

import 'package:flutter/material.dart';
import 'package:smartplacementassistant/pages/student_tpo_page.dart';
import 'package:smartplacementassistant/utilsapp/app_colors.dart';
class SplashPage extends StatefulWidget {
  const SplashPage({Key? key}) : super(key: key);

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {

  @override
  void initState() {
    super.initState();
    Timer(Duration(seconds: 3),
            ()=>Navigator.pushReplacement(context,
            MaterialPageRoute(builder:
                (context) =>
                StudentTpoPage()
            )
        )
    );
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,

      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [

          Container(
            margin:   EdgeInsets.fromLTRB(20, 100, 20, 5),
            child:Image.asset("assets/images/logo.png"),
          ),

          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              color: Colors.white,
              margin:   EdgeInsets.fromLTRB(20, 20, 20, 15),
              child:   DefaultTextStyle(
                style: TextStyle(fontSize:15,color: Colors.black,fontWeight: FontWeight.bold,fontStyle: FontStyle.normal),
                child: Text(
                  'Smart Placement Assistant App',
                ),
              ),
            ),
          ),


        ],

      ),


    );
  }
}
