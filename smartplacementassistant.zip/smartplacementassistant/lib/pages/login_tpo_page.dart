import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smartplacementassistant/models/user_model.dart';
import 'package:smartplacementassistant/utilsapp/app_constant.dart';

import '../my_routes.dart';
import '../utilsapp/app_colors.dart';
class LoginTpoPage extends StatefulWidget {
  static String tag = 'login-tpo-page';
  const LoginTpoPage({Key? key}) : super(key: key);

  @override
  State<LoginTpoPage> createState() => _LoginTpoPageState();
}

class _LoginTpoPageState extends State<LoginTpoPage> {
  final _formKeyEmail = GlobalKey<FormState>();
  final _formKeyPass = GlobalKey<FormState>();

  //key for form
  final _auth = FirebaseAuth.instance;
  late DatabaseReference _dbref;
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passController = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _dbref = FirebaseDatabase.instance.reference();


  }
  @override
  Widget build(BuildContext context) {


    final signin_button=  Container(
      margin: EdgeInsets.fromLTRB(10, 10, 10, 10),
      width: MediaQuery.of(context).size.width * 0.91,
      height: 55,
      child: ElevatedButton(

        onPressed: () async {
          await signIn(emailController.text, passController.text);
        },
        style: ElevatedButton.styleFrom(
          primary: AppColor.button_color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10  ),
          ),
          elevation: 15.0,
        ),
        child:  Text(
          "Sign In",
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );
    return    Scaffold(
      backgroundColor: AppColor.bg_color,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(
              height: 50,
            ),

            Align(
              alignment: Alignment.center,
              child: Container(
                margin:   EdgeInsets.fromLTRB(20, 20, 20, 5),
                child:   Text(
                  'Hello',
                  style: TextStyle(fontSize:40,color: Colors.black,fontWeight: FontWeight.bold),
                ),
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: Container(
                margin: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                child: const Text(
                  'Login As TPO! ',
                  style: TextStyle(fontSize: 20),
                ),
              ),
            ),

            Padding(
              padding:  EdgeInsets.all(20.0),
              child: Column(

                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Form(
                      autovalidateMode: AutovalidateMode.onUserInteraction,
                      key: _formKeyEmail,
                      child: TextFormField(
                        controller: emailController,
                        decoration: InputDecoration(
                          labelText: 'Email',
                          filled: true,
                          fillColor: AppColor.textfieldColor,
                          contentPadding:  EdgeInsets.fromLTRB(20, 15, 20, 15),
                          enabledBorder:   OutlineInputBorder(
                            // width: 0.0 produces a thin "hairline" border
                            borderSide: const BorderSide(color: Colors.white, width: 0.0),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),


                        ),
                        autofocus: false,
                        keyboardType: TextInputType.emailAddress,
                        validator: (value) {
                          if (value!.isEmpty) {
                            return "Please Enter Email";
                          }
                          if (!RegExp("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+.[a-z]")
                              .hasMatch(value)) {
                            return "Enter a valid email";
                          }
                          // return null;
                        },
                        // onSaved: (value) {
                        //   emailController.text = value!;
                        // },
                        textInputAction: TextInputAction.next,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Form(
                      key: _formKeyPass,
                      child: TextFormField(
                        controller: passController,
                        obscureText: true,
                        decoration: InputDecoration(
                          labelText: 'Password',
                          filled: true,
                          fillColor: AppColor.textfieldColor,
                          contentPadding: const EdgeInsets.fromLTRB(20, 15, 20, 15),
                          enabledBorder:   OutlineInputBorder(
                            // width: 0.0 produces a thin "hairline" border
                            borderSide: const BorderSide(color: Colors.white, width: 0.0),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        validator: (value) {
                          RegExp regExp = RegExp(r'^.{6,20}$');
                          if (value!.isEmpty) {
                            return ("Required Password");
                          }
                          if (!regExp.hasMatch(value)) {
                            return ("Please Enter Min. 6 Characters and Max. 20");
                          }
                        },
                        autofocus: false,
                        onSaved: (value) {
                          passController.text = value!;
                        },
                        textInputAction: TextInputAction.done,
                      ),
                    ),
                  ),
                  Center(
                    child: signin_button,
                  ),



                ],),
            ),


          ],
        ),
      ),
    );
  }

  Future<void> signIn(String email, String password) async {
    try {
      if (_formKeyEmail.currentState!.validate() &&
          _formKeyPass.currentState!.validate()) {

        await _dbref.child(AppConstant.MAIN_TABLE).child("tpo")
            .orderByChild("email").equalTo(email).once()
            .then((snapshot) {
          print("valueupdate " + snapshot.value.toString());

          if (snapshot.exists) {
             Map<dynamic, dynamic> values = snapshot.value;
             values.forEach((key,values) {
              print(values["password"]);
               if(password==values["password"].toString())
                {
                  print(password + " " +values["password"].toString());
                  AppConstant.uid_string=values["uid"].toString();
                  Fluttertoast.showToast(msg: 'Login Successful');
                   Navigator.pushNamed(context, MyRoutes.tpoDashboardRoute);
                }else{
                 print(password + " " +values["password"].toString());
                Fluttertoast.showToast(msg: 'wrong Password');
              }

            });

          } else {
            Fluttertoast.showToast(msg: 'User not found!');
          }

        });
      }



    } on FirebaseAuthException catch (error) {
      Fluttertoast.showToast(msg: 'Failed With Error Code: ${error.code}');
      Fluttertoast.showToast(msg: email.toString() + " " + password.toString());
      Fluttertoast.showToast(msg: error.toString());
      print(error.toString());
    }
  }
}
