import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../utilsapp/app_colors.dart';
class ForgotPasswordPage extends StatefulWidget {
  const ForgotPasswordPage({Key? key}) : super(key: key);

  @override
  State<ForgotPasswordPage> createState() => _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends State<ForgotPasswordPage> {
  final _formKeyEmail = GlobalKey<FormState>();
  final TextEditingController emailController = TextEditingController();
  final _auth = FirebaseAuth.instance;

  @override
  void dispose(){
    emailController.dispose();
    super.dispose();

  }
  @override
  Widget build(BuildContext context) {

    final signin_button=  Container(
      margin: EdgeInsets.fromLTRB(10, 10, 10, 10),
      width: MediaQuery.of(context).size.width * 0.91,
      height: 55,
      child: ElevatedButton(

        onPressed: () async {
          await forgotPasswordSubmit(emailController.text);
        },
        style: ElevatedButton.styleFrom(
          primary: AppColor.button_color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10  ),
          ),
          elevation: 15.0,
        ),
        child:  Text(
          "Submit",
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );
    return Scaffold(
      backgroundColor: AppColor.bg_color,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Align(
                alignment: Alignment.center,
                child: Container(
                  margin:   EdgeInsets.fromLTRB(20, 120, 20, 5),
                  child:   Text(
                    'Forgot Password?',
                    style: TextStyle(fontSize:20,color: Colors.black,fontWeight: FontWeight.bold),
                  ),



                ),
              ),


              Container(
                margin: EdgeInsets.fromLTRB(20, 20, 20, 10),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Form(
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    key: _formKeyEmail,
                    child: TextFormField(
                      controller: emailController,
                      decoration: InputDecoration(
                        labelText: 'Email',
                        filled: true,
                        fillColor: AppColor.textfieldColor,
                        contentPadding:  EdgeInsets.fromLTRB(20, 15, 20, 15),
                        enabledBorder:   OutlineInputBorder(
                          // width: 0.0 produces a thin "hairline" border
                          borderSide: const BorderSide(color: Colors.white, width: 0.0),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),


                      ),
                      autofocus: false,
                      keyboardType: TextInputType.emailAddress,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return "Please Enter Email";
                        }
                        if (!RegExp("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+.[a-z]")
                            .hasMatch(value)) {
                          return "Enter a valid email";
                        }
                        // return null;
                      },
                      // onSaved: (value) {
                      //   emailController.text = value!;
                      // },
                      textInputAction: TextInputAction.next,
                    ),
                  ),
                ),
              ),

              signin_button,


    Align(
    alignment: Alignment.center,
    child: Container(
    margin:   EdgeInsets.fromLTRB(20, 120, 20, 5),
    child:   Text(
    'Check your email for reset link',
    style: TextStyle(fontSize:16,color: Colors.blue,fontWeight: FontWeight.bold),
    ),),),
            ],
          ),
        ),
      ),
    );
  }

  Future forgotPasswordSubmit(String email) async {

    if (_formKeyEmail.currentState!.validate()) {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
        print("email $email");
      Fluttertoast.showToast(msg: 'Reset Password email is sent!');
      emailController.text="";
    }
  }


}
