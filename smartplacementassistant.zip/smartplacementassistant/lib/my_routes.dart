class MyRoutes {
  static String homeRoute = "/home";
  static String dashBoardRoute = "/student_dashboard";
  static String profileRoute = "/profile_page";
  static String fillApplicationRoute = "/fill_application";
  static String personalDetailsRoute = "/personalDetails";
  static String academicDetailsRoute = "/academicDetails";
  static String contactDetailsRoute = "/contactDetails";
  static String contactUsRoute = "/contactUspage";

  static String loginRoute = "/login_page";
  static String signupRoute = "/signup_page";
  static String forgotpasswordRoute = "/forgot_password";
  static String notificationsRoute = "/notifications_page";
  static String changePasswordRoute = "/changePassword_page";

  static String tpoDashboardRoute = "/tpo_dashboard";
  static String tpoProfileRoute = "/tpo_profile";
  static String tpoPersonalDetailsRoute = "/tpo_personal_details";
  static String tpoContactDetailsRoute = "/tpoContactDetails";
  static String studentListRoute = "/studentList";
  static String noticeRoute = "/notice_page";



}