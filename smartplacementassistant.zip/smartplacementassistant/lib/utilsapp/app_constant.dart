class AppConstant{


  static String MAIN_TABLE="users";
  static String STUDENT_TABLE="student";
  static String TPO_TABLE="tpo";
  static String PERSONAL_DETAILS_TABLE="personal_details";
  static String ACADEMIC_DETAILS_TABLE="academic_details";
  static String CONTACT_DETAILS_TABLE="contact_details";

  static String name_string = "name";
  static String email_string = "email";
  static String uid_string = "uid";
  static String notice_string = "notice";

}