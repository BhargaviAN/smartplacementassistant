import 'dart:ui';

class AppColor{
  static const bg_color =  Color(0xFFE0DFDF);
  static const dashboard_color =  Color(0xFF728DB9);
  static const button_color =  Color(0xFF1A237E);
  static const textfieldColor =  Color(0xFFEEEEEE);
  static const ErroColor =  Color(0xFF808080);
}