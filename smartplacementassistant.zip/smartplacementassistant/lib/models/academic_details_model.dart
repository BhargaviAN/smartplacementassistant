class AcademicDetailsModel{

  String? tenth_per;
  String? twel_per;
  String? degree_cgpa;
  String? backlogs;
  String? department;

  AcademicDetailsModel({this.tenth_per, this.twel_per, this.degree_cgpa,this.backlogs,this.department});

  Map<String, dynamic> toMap() {
    return {
      'tenth_per': this.tenth_per,
      'twel_per': this.twel_per,
      'degree_cgpa': this.degree_cgpa,
      'backlogs': this.backlogs,
      'department': this.department,
    };
  }

  factory AcademicDetailsModel.fromMap(Map<String, dynamic> map) {
    return AcademicDetailsModel(
      tenth_per: map['tenth_per'] as String,
      twel_per: map['twel_per'] as String,
      degree_cgpa: map['degree_cgpa'] as String,
      backlogs: map['backlogs'] as String,
      department: map['department'] as String,
    );
  }
}