class NotificationModel{

  String? notification_text;
  String? date_and_time;
  String? id;


  Map<String, dynamic> toMap() {
    return {
      'notification_text': this.notification_text,
      'date_and_time': this.date_and_time,
      'id': this.id,
    };
  }

  factory NotificationModel.fromMap(Map<String, dynamic> map) {
    return NotificationModel(
      notification_text: map['notification_text'] as String,
      date_and_time: map['date_and_time'] as String,
      id: map['id'] as String,
    );
  }

  NotificationModel({
    this.notification_text,
    this.date_and_time,
    this.id,
  });
}