
class TpoPersonalDetailsModel{


  String? first_name;
  String? last_name;
  String? department;
  String? gender;

  TpoPersonalDetailsModel({this.first_name, this.last_name,
     this.gender, this.department});

  Map<String, dynamic> toMap() {
    return {
      'first_name': this.first_name,
      'last_name': this.last_name,
      'department': this.department,
      'gender': this.gender,
    };
  }

  factory TpoPersonalDetailsModel.fromMap(Map<String, dynamic> map) {
    return TpoPersonalDetailsModel(
      first_name: map['first_name'] as String,
      last_name: map['last_name'] as String,
      department: map['department'] as String,
      gender: map['gender'] as String,
    );
  }
}