class ContactDetailsModel{
  String? parent_email;
  String? contact_number;
  String? parent_contact_number;
  String? address;

  ContactDetailsModel({
    this.parent_email,
    this.contact_number,
    this.parent_contact_number,
    this.address,
  });

  Map<String, dynamic> toMap() {
    return {
      'parent_email': this.parent_email,
      'contact_number': this.contact_number,
      'parent_contact_number': this.parent_contact_number,
      'address': this.address,
    };
  }

  factory ContactDetailsModel.fromMap(Map<String, dynamic> map) {
    return ContactDetailsModel(
      parent_email: map['parent_email'] as String,
      contact_number: map['contact_number'] as String,
      parent_contact_number: map['parent_contact_number'] as String,
      address: map['address'] as String,
    );
  }

  @override
  String toString() {
    return 'ContactDetailsModel{parent_email: $parent_email, contact_number: $contact_number, parent_contact_number: $parent_contact_number, address: $address}';
  }
}