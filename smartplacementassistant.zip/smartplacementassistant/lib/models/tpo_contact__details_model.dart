class TpoContactDetailsModel{
  String? email;
  String? contact_number;
  String? second_contact_number;

  TpoContactDetailsModel({
    this.email,
    this.contact_number,
    this.second_contact_number,
  });

  Map<String, dynamic> toMap() {
    return {
      'email': this.email,
      'contact_number': this.contact_number,
      'second_contact_number': this.second_contact_number,
    };
  }

  factory TpoContactDetailsModel.fromMap(Map<String, dynamic> map) {
    return TpoContactDetailsModel(
      email: map['email'] as String,
      contact_number: map['contact_number'] as String,
      second_contact_number: map['second_contact_number'] as String,
    );
  }
}