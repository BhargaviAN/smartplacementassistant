class UserModel{

  String? name;
  String? email;
  String? uid;
  String? password;
  String? user_type;
  String? department;
  String? cgpa;

  UserModel({
    this.name,
    this.email,
    this.uid,
    this.password,
    this.user_type,
    this.department,
    this.cgpa,
  });

  Map<String, dynamic> toMap() {
    return {
      'name': this.name,
      'email': this.email,
      'uid': this.uid,
      'password': this.password,
      'user_type': this.user_type,
      'department': this.department,
      'cgpa': this.cgpa,
    };
  }

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      name: map['name'] as String,
      email: map['email'] as String,
      uid: map['uid'] as String,
      password: map['password'] as String,
      user_type: map['user_type'] as String,
      department: map['department'] as String,
      cgpa: map['cgpa'] as String,
    );
  }
}