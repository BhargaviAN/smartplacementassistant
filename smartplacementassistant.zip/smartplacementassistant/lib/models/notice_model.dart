class NoticeModel{

  String? notice;
  String? date_and_time;
  String? id;


  Map<String, dynamic> toMap() {
    return {
      'notice': this.notice,
      'date_and_time': this.date_and_time,
      'id': this.id,
    };
  }

  factory NoticeModel.fromMap(Map<String, dynamic> map) {
    return NoticeModel(
      notice: map['notice'] as String,
      date_and_time: map['date_and_time'] as String,
      id: map['id'] as String,
    );
  }

  NoticeModel({
    this.notice,
    this.date_and_time,
    this.id,
  });
}