class PersonalDetailsModel{

  String? universityseat_no;
  String? first_name;
  String? middle_name;
  String? last_name;
  String? dob;
  String? gender;

  PersonalDetailsModel({this.universityseat_no, this.first_name, this.middle_name, this.last_name,
      this.dob, this.gender});

  Map<String, dynamic> toMap() {
    return {
      'universityseat_no': this.universityseat_no,
      'first_name': this.first_name,
      'middle_name': this.middle_name,
      'last_name': this.last_name,
      'dob': this.dob,
      'gender': this.gender,
    };
  }

  factory PersonalDetailsModel.fromMap(Map<String, dynamic> map) {
    return PersonalDetailsModel(
      universityseat_no: map['university_no'] as String,
      first_name: map['first_name'] as String,
      middle_name: map['middle_name'] as String,
      last_name: map['last_name'] as String,
      dob: map['dob'] as String,
      gender: map['gender'] as String,
    );
  }
}