import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:smartplacementassistant/models/tpo_contact__details_model.dart';
import 'package:smartplacementassistant/pages/forgot_password_page.dart';
import 'package:smartplacementassistant/pages/login_page.dart';
import 'package:smartplacementassistant/pages/signup_page.dart';
import 'package:smartplacementassistant/pages/splash_page.dart';
import 'package:smartplacementassistant/pages/student/academic_details.dart';
import 'package:smartplacementassistant/pages/student/change_password_page.dart';
import 'package:smartplacementassistant/pages/student/contact_details.dart';
import 'package:smartplacementassistant/pages/student/contact_us_page.dart';
import 'package:smartplacementassistant/pages/student/fill_application.dart';
import 'package:smartplacementassistant/pages/student/notifications_page.dart';
import 'package:smartplacementassistant/pages/student/personal_details.dart';
import 'package:smartplacementassistant/pages/student/profile_page.dart';
import 'package:smartplacementassistant/pages/student_dashboard.dart';
import 'package:smartplacementassistant/pages/tpo/add_notice_page.dart';
import 'package:smartplacementassistant/pages/tpo/student_list.dart';
import 'package:smartplacementassistant/pages/tpo/tpo_contact_details.dart';
import 'package:smartplacementassistant/pages/tpo/tpo_dashboard.dart';
import 'package:smartplacementassistant/pages/tpo/tpo_personal_details.dart';
import 'package:smartplacementassistant/pages/tpo/tpo_profile_page.dart';

import 'my_routes.dart';


Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp( MyApp());
}

class MyApp extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).requestFocus(new FocusNode());
      },
      child: MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Smart Placement Assistant',
          theme: ThemeData(
            primarySwatch: Colors.blue,
          ),
          home: MaterialApp(
            title: 'App',
            debugShowCheckedModeBanner: false,
            theme: ThemeData(
              primarySwatch: Colors.lightBlue,
              fontFamily: 'Nunito',
            ),
         home: SplashPage(),
          //  initialRoute: "/login",
            routes: {
               MyRoutes.dashBoardRoute: (context) => StudentDashboard(),
               MyRoutes.loginRoute: (context) => LoginPage(),
               MyRoutes.signupRoute: (context) => SignupPage(),
               MyRoutes.profileRoute: (context) => ProfilePage(),
               MyRoutes.forgotpasswordRoute: (context) => ForgotPasswordPage(),
               MyRoutes.fillApplicationRoute: (context) => FillApplicationPage(),
               MyRoutes.personalDetailsRoute: (context) => PersonalDetailsPage(),
               MyRoutes.academicDetailsRoute: (context) => AcademicDetailsPage(),
               MyRoutes.contactDetailsRoute: (context) => ContactDetailsPage(),
               MyRoutes.changePasswordRoute: (context) => ChangePasswordPage(),
               MyRoutes.contactUsRoute: (context) => ContactUsPage(),
               MyRoutes.notificationsRoute: (context) => NotificationsPage(),
               MyRoutes.tpoDashboardRoute: (context) => TpoDashboard(),
               MyRoutes.tpoProfileRoute: (context) => TpoProfilePage(),
               MyRoutes.tpoPersonalDetailsRoute: (context) => TpoPersonalDetailsPage(),
               MyRoutes.tpoContactDetailsRoute: (context) => TpoContactDetailsPage(),
               MyRoutes.studentListRoute: (context) => StudentListPage(),

            },
          )),
    );
  }
}