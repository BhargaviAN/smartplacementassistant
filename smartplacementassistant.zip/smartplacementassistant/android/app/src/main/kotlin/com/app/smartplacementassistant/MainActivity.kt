package com.app.smartplacementassistant

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
